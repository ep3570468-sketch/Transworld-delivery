'use strict';
// Installation en 1 clic (à ouvrir UNE fois dans le navigateur après chaque (ré)hébergement) :
//   https://VOTRE-SITE/api/setup?key=VOTRE_TELEGRAM_SECRET
// Fait : 1) crée les tables Postgres  2) branche le webhook Telegram  3) installe le menu du bot  4) vous envoie un message de test.
// Protégé par TELEGRAM_SECRET. Ne renvoie jamais le token.
const crypto = require('crypto');
const C = require('./_lib/core');
const { q } = require('./_lib/db');
const SCHEMA = require('./_lib/schema');

const COMMANDS = [
  { command: 'liste', description: 'Mes colis (boutons)' },
  { command: 'colis', description: "Panneau d'un colis (boutons)" },
  { command: 'nouveau', description: 'Créer un colis + code client' },
  { command: 'progres', description: "Faire avancer l'icône sur la carte" },
  { command: 'statut', description: 'Changer le statut (et le lieu)' },
  { command: 'position', description: 'Mettre à jour la carte (lieu ou GPS)' },
  { command: 'transport', description: "Changer l'icône (avion, bateau, camion…)" },
  { command: 'details', description: 'Ajouter / modifier les informations du colis' },
  { command: 'message', description: 'Envoyer un message au client' },
  { command: 'code', description: "Nouveau code d'accès" },
  { command: 'supprimer', description: 'Supprimer un ancien code de suivi' },
  { command: 'nettoyer', description: 'Supprimer tous les anciens codes' },
  { command: 'devis', description: 'Demandes de devis / contact' },
  { command: 'stats', description: 'Statistiques' },
  { command: 'aide', description: 'Toutes les commandes' },
];

module.exports = async (req, res) => {
  const out = (code, obj) => { res.statusCode = code; res.setHeader('Content-Type', 'application/json; charset=utf-8'); res.setHeader('Cache-Control', 'no-store'); res.end(JSON.stringify(obj, null, 2)); };
  const secret = C.env('TELEGRAM_SECRET'), token = C.env('TELEGRAM_TOKEN');
  const key = String((req.query && req.query.key) || new URL(req.url, 'http://x').searchParams.get('key') || '');
  const a = Buffer.from(secret), b = Buffer.from(key);
  if (!secret || a.length !== b.length || !crypto.timingSafeEqual(a, b)) return out(403, { ok: false, error: 'Clé invalide. Utilisez /api/setup?key=<valeur de TELEGRAM_SECRET>' });

  const report = { env: {
    TELEGRAM_TOKEN: !!token, TELEGRAM_SECRET: !!secret, DATABASE_URL: !!(process.env.DATABASE_URL || process.env.POSTGRES_URL || C.env('DATABASE_URL')),
    SESSION_SECRET: !!C.env('SESSION_SECRET'), SITE_URL: C.siteUrl() || 'MANQUANT', TELEGRAM_ALLOWED_membres: Object.values(C.team()),
  } };
  if (!token) return out(400, { ok: false, error: 'TELEGRAM_TOKEN manquant dans les variables Vercel.', ...report });
  if (!/^[A-Za-z0-9_-]{1,256}$/.test(secret)) return out(400, { ok: false, error: 'TELEGRAM_SECRET : uniquement lettres, chiffres, _ et - (Telegram refuse le reste).', ...report });
  if (!/^https:\/\//.test(C.siteUrl())) return out(400, { ok: false, error: 'SITE_URL doit commencer par https://', ...report });

  try { await q(SCHEMA); report.base = 'OK : tables créées / à jour'; }
  catch (e) { report.base = 'ERREUR : ' + e.message; return out(500, { ok: false, ...report }); }

  const api = (m, body) => fetch('https://api.telegram.org/bot' + token + '/' + m, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) }).then((r) => r.json()).catch((e) => ({ ok: false, description: e.message }));
  const me = await api('getMe');
  if (!me.ok) { report.bot = 'ERREUR token : ' + (me.description || '?') + ' (token faux, incomplet ou révoqué)'; return out(400, { ok: false, ...report }); }
  report.bot = '@' + me.result.username;
  const wh = await api('setWebhook', { url: C.siteUrl() + '/api/telegram', secret_token: secret, allowed_updates: ['message', 'edited_message', 'callback_query'], drop_pending_updates: true });
  report.webhook = wh.ok ? 'OK : ' + C.siteUrl() + '/api/telegram' : 'ERREUR : ' + wh.description;
  const mc = await api('setMyCommands', { commands: COMMANDS });
  report.menu = mc.ok ? 'OK' : 'ERREUR : ' + mc.description;
  const info = await api('getWebhookInfo');
  report.telegram_last_error = (info.result && info.result.last_error_message) || null;

  const ids = Object.keys(C.team());
  if (!ids.length) report.test = 'Aucun membre dans TELEGRAM_ALLOWED';
  else { await Promise.allSettled(ids.map((id) => C.tgSend(Number(id), '✅ <b>TRANSWORLD DELIVERY</b> : bot branché.\nTapez /aide pour les commandes, puis <code>/nouveau</code> pour créer un colis et son code.'))); report.test = 'Message envoyé sur Telegram : vérifiez votre bot'; }

  return out(wh.ok && mc.ok ? 200 : 500, { ok: !!(wh.ok && mc.ok), ...report });
};
