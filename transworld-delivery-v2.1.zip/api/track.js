'use strict';
// POST { tracking, code } -> données publiques du colis (statuts, carte, messages)
const C = require('./_lib/core');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return C.send(res, 405, { error: 'method_not_allowed' });
  const inp = C.readJson(req);
  if (!inp) return C.send(res, 400, { error: 'bad_request' });

  try {
    const no = String(inp.tracking || '').trim().toUpperCase();
    const code = String(inp.code || '');
    const ip = C.clientIp(req);

    // Limite par IP : 60 requêtes / 10 minutes (le suivi en direct consomme 1 requête / 20 s)
    if ((await C.rateCount('track:' + ip, 600)) >= 60) {
      return C.send(res, 429, { error: 'rate_limited', message: 'Too many attempts. Please try again in a few minutes.' });
    }
    await C.rateHit('track:' + ip);

    const notFound = { error: 'not_found', message: 'No shipment found for this tracking number. Please check it and try again.' };
    if (!/^TWD-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(no)) return C.send(res, 404, notFound);

    const s = await C.one('SELECT * FROM shipments WHERE tracking_number = $1 AND archived = FALSE', [no]);
    if (!s || !s.tracking_enabled) return C.send(res, 404, notFound);

    const grants = C.getGrants(req);
    const granted = !!grants[no];

    if (!granted && s.access_mode !== 'none') {
      const mode = s.access_mode;
      if (mode === 'one_time' && s.access_used_at) {
        return C.send(res, 403, { error: 'code_used', message: 'This access code has already been used. Please contact TRANSWORLD DELIVERY.' });
      }
      if ((mode === 'temporary' || mode === 'one_time') && s.access_expires_at && new Date(s.access_expires_at) < new Date()) {
        return C.send(res, 403, { error: 'code_expired', message: 'This access code has expired. Please contact TRANSWORLD DELIVERY.' });
      }
      if (!code.trim()) return C.send(res, 401, { error: 'code_required', need_code: true, message: 'Please enter your verification code.' });

      // Anti brute-force : 5 codes faux / 15 minutes par colis et par IP
      const bucket = 'codefail:' + no + ':' + ip;
      if ((await C.rateCount(bucket, 900)) >= 5) {
        return C.send(res, 429, { error: 'rate_limited', message: 'Too many incorrect codes. Please try again in 15 minutes.' });
      }
      if (!C.verifyCode(code, s.access_token_hash)) {
        await C.rateHit(bucket);
        return C.send(res, 401, { error: 'invalid_code', need_code: true, message: 'Invalid verification code.' });
      }
      if (mode === 'one_time') {
        // Invalidation atomique : un seul visiteur peut consommer le code
        const u = await C.q('UPDATE shipments SET access_used_at = now() WHERE id = $1 AND access_used_at IS NULL RETURNING id', [s.id]);
        if (u.length !== 1) return C.send(res, 403, { error: 'code_used', message: 'This access code has already been used. Please contact TRANSWORLD DELIVERY.' });
        await C.tgAlert('🔓 One-time code used for <code>' + no + '</code>.');
      }
      // Accès conservé dans ce navigateur : 24 h (code permanent), 30 min (code temporaire / à usage unique)
      grants[no] = Math.floor(Date.now() / 1000) + (mode === 'permanent' ? 86400 : 1800);
      C.setGrants(res, grants);
    }

    const [events, trailDesc, messages] = await Promise.all([
      C.q('SELECT status, location, description, event_date FROM tracking_events WHERE shipment_id = $1 ORDER BY event_date DESC, id DESC LIMIT 100', [s.id]),
      C.q('SELECT label, latitude, longitude, source, created_at FROM positions WHERE shipment_id = $1 ORDER BY created_at DESC, id DESC LIMIT 60', [s.id]),
      C.q('SELECT body, created_at FROM messages WHERE shipment_id = $1 AND visible = TRUE ORDER BY created_at DESC, id DESC LIMIT 50', [s.id]),
    ]);
    return C.send(res, 200, { ok: true, shipment: C.publicPayload(s, events, trailDesc.reverse(), messages) });
  } catch (e) {
    console.error('[TWD track]', e.message);
    return C.send(res, 500, { error: 'server_error', message: 'Live tracking temporarily unavailable. Please try again later.' });
  }
};
