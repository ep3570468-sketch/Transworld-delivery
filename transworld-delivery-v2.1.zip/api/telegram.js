'use strict';
// Webhook du bot Telegram TRANSWORLD DELIVERY - RÉSERVÉ À L'ÉQUIPE (liste blanche d'ID Telegram).
// Le bot remplace le panneau admin : création de colis, codes, statuts, positions, messages clients, devis.
const crypto = require('crypto');
const C = require('./_lib/core');
const { q, one, esc } = C;

const METHODS = { air: 'Air Freight', mer: 'Sea Freight', sea: 'Sea Freight', maritime: 'Sea Freight', terre: 'Land Freight', land: 'Land Freight', route: 'Land Freight', rail: 'Rail Freight', train: 'Rail Freight', express: 'Express Delivery', vehicule: 'Vehicle Transport' };
const ALIAS = { RECU: 'RECEIVED', TRAITEMENT: 'PROCESSING', RAMASSE: 'PICKED_UP', PICKUP: 'PICKED_UP', TRANSIT: 'IN_TRANSIT', ENROUTE: 'IN_TRANSIT', ARRIVE: 'ARRIVED_DESTINATION', ARRIVED: 'ARRIVED_DESTINATION', DOUANE: 'CUSTOMS_CLEARANCE', CUSTOMS: 'CUSTOMS_CLEARANCE', DEDOUANE: 'CUSTOMS_CLEARED', CLEARED: 'CUSTOMS_CLEARED', DEPOT: 'LOCAL_FACILITY', LIVRAISON: 'OUT_FOR_DELIVERY', OUT: 'OUT_FOR_DELIVERY', LIVRE: 'DELIVERED', DELIVERE: 'DELIVERED', RETARD: 'DELAYED', PROBLEME: 'EXCEPTION', ANNULE: 'CANCELLED', CONFIRME: 'CONFIRMED' };
const CODE_MODES = { permanent: 'permanent', perm: 'permanent', temporaire: 'temporary', temp: 'temporary', temporary: 'temporary', unique: 'one_time', once: 'one_time', one_time: 'one_time', aucun: 'none', none: 'none' };
const MAIL_ON = ['IN_TRANSIT', 'ARRIVED_DESTINATION', 'CUSTOMS_CLEARANCE', 'OUT_FOR_DELIVERY', 'DELIVERED', 'DELAYED'];
const FIELDS = {
  nom: 'customer_name', email: 'customer_email', telephone: 'customer_phone', tel: 'customer_phone', poids: 'weight', quantite: 'quantity', dimensions: 'dimensions', type: 'package_type',
  description: 'description', contenu: 'description', valeur: 'declared_value', depart: 'shipment_date', methode: 'shipping_method', note: 'admin_note',
  transporteur: 'carrier_name', compagnie: 'carrier_name', navire: 'carrier_name', reference: 'carrier_ref', vol: 'carrier_ref', conteneur: 'carrier_ref', service: 'service_level',
  destinataire: 'receiver_name', teldest: 'receiver_phone', adresse: 'receiver_address', assurance: 'insured', paiement: 'payment_status', manutention: 'special_handling', fragile: 'special_handling',
};
const REQUIRED = ['customer_name', 'quantity', 'shipping_method', 'insured'];
const PAY = { paye: 'paid', payé: 'paid', paid: 'paid', attente: 'pending', pending: 'pending', partiel: 'partial', partial: 'partial' };
const LEN = { description: 2000, admin_note: 2000, receiver_address: 250, special_handling: 200, carrier_name: 120, receiver_name: 150, customer_name: 150, customer_email: 190, carrier_ref: 80, service_level: 60, package_type: 60, dimensions: 80, customer_phone: 40, receiver_phone: 40 };

/** Valide une valeur de champ : { col, val } ou { err }. « - » efface un champ facultatif. */
function parseField(field, raw) {
  const col = FIELDS[String(field || '').toLowerCase()];
  if (!col) return { err: 'Champ inconnu « ' + field + ' ». Champs : ' + Object.keys(FIELDS).join(', ') + '.' };
  let val = String(raw || '').trim();
  if (!val) return { err: 'Valeur manquante pour « ' + field + ' ».' };
  if (val === '-') return REQUIRED.includes(col) ? { err: '« ' + field + ' » ne peut pas être vide.' } : { col, val: null };
  if (col === 'customer_email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) return { err: 'Email invalide.' };
  if (col === 'weight' || col === 'declared_value') { if (!isNum(val)) return { err: 'Valeur numérique attendue pour « ' + field + ' ».' }; val = toNum(val); }
  else if (col === 'quantity') { if (!/^\d+$/.test(val) || parseInt(val, 10) < 1) return { err: 'Quantité : nombre entier ≥ 1.' }; val = parseInt(val, 10); }
  else if (col === 'shipment_date') { if (!/^\d{4}-\d{2}-\d{2}$/.test(val)) return { err: 'Date : AAAA-MM-JJ.' }; }
  else if (col === 'shipping_method') { val = METHODS[val.toLowerCase()]; if (!val) return { err: 'Méthode : air, mer, terre, rail, express, vehicule.' }; }
  else if (col === 'insured') { const v = val.toLowerCase(); if (['oui', 'yes', 'o', 'y', '1', 'true'].includes(v)) val = true; else if (['non', 'no', 'n', '0', 'false'].includes(v)) val = false; else return { err: 'Assurance : oui ou non.' }; }
  else if (col === 'payment_status') { val = PAY[val.toLowerCase()]; if (!val) return { err: 'Paiement : paye, attente ou partiel.' }; }
  else val = val.slice(0, LEN[col] || 150);
  return { col, val };
}
/** Applique plusieurs [champ, valeur] à un colis. Renvoie { done: [...], errs: [...] }. */
async function applyFields(s, pairs, who) {
  const done = [], errs = [];
  for (const [f, v] of pairs) {
    const r = parseField(f, v);
    if (r.err) { errs.push(r.err); continue; }
    await q('UPDATE shipments SET ' + r.col + ' = $1, updated_at = now() WHERE id = $2', [r.val, s.id]); // r.col vient de la liste blanche FIELDS
    if (r.col === 'shipping_method') await q('UPDATE shipments SET transport_mode = $1 WHERE id = $2', [C.METHOD_TO_MODE[r.val] || null, s.id]);
    done.push(f.toLowerCase());
  }
  if (done.length) await C.logActivity(who, 'shipment_update', s.id, '[Telegram: ' + who + '] ' + s.tracking_number + ' | ' + done.join(', ') + ' updated');
  return { done, errs };
}

const resolveStatus = (s) => {
  const k = String(s || '').trim().toUpperCase().replace(/[\s-]+/g, '_');
  return C.STATUSES[k] ? k : ALIAS[k.replace(/_/g, '')] || ALIAS[k] || null;
};
const isNum = (v) => /^-?\d+([.,]\d+)?$/.test(String(v));
const toNum = (v) => parseFloat(String(v).replace(',', '.'));
const TRK = /^TWD-[A-Z0-9]{4}-[A-Z0-9]{4}$/;
const MODE_ICON = { air: '✈️', sea: '🚢', land: '🚚', rail: '🚆', express: '⚡', vehicle: '🚗' };

async function findShip(no) {
  no = String(no || '').trim().toUpperCase();
  if (!TRK.test(no)) return null;
  return one('SELECT * FROM shipments WHERE tracking_number = $1', [no]);
}

function describe(s) {
  const acc = { none: 'aucun (numéro seul)', permanent: 'code permanent', temporary: 'code temporaire', one_time: 'code à usage unique' }[s.access_mode] || s.access_mode;
  let a = acc;
  if (s.access_expires_at) a += ', expire ' + C.fmtDate(s.access_expires_at);
  if (s.access_used_at) a += ', UTILISÉ ' + C.fmtDate(s.access_used_at);
  return '📦 <code>' + esc(s.tracking_number) + '</code>\n<b>' + esc(C.statusLabel(s.status)) + '</b> (' + s.progress + '%)\n👤 ' + esc(s.customer_name) + ' ' + esc(s.customer_phone || '') + ' ' + esc(s.customer_email || '') +
    '\n🛣 ' + esc(s.origin_city + ', ' + s.origin_country) + ' → ' + esc(s.destination_city + ', ' + s.destination_country) +
    '\n📍 ' + esc(s.current_location || '-') + '\n📅 ETA : ' + esc(s.estimated_delivery || '-') + '\n🔐 Accès : ' + esc(a) +
    '\n🌐 Suivi public : ' + (s.tracking_enabled ? 'ON' : 'OFF') + (s.archived ? '\n🗄 ARCHIVÉ' : '') +
    '\n\n🧭 Transport : ' + esc(MODE_ICON[C.modeOf(s)] + ' ' + C.MODES[C.modeOf(s)]) + (s.carrier_name ? ' · ' + esc(s.carrier_name) : '') + (s.carrier_ref ? ' · ' + esc(s.carrier_ref) : '') +
    (s.service_level ? '\n⚡ Service : ' + esc(s.service_level) : '') +
    '\n📦 ' + esc([s.package_type, s.weight != null ? s.weight + ' kg' : null, s.quantity ? 'x' + s.quantity : null, s.dimensions].filter(Boolean).join(' · ') || '-') +
    (s.description ? '\n📝 ' + esc(s.description.slice(0, 160)) : '') + (s.special_handling ? '\n⚠️ ' + esc(s.special_handling) : '') +
    '\n🛡 Assuré : ' + (s.insured ? 'oui' : 'non') + (s.payment_status ? ' · 💳 ' + esc(s.payment_status) : '') +
    (s.receiver_name || s.receiver_phone || s.receiver_address ? '\n📥 Destinataire : ' + esc([s.receiver_name, s.receiver_phone, s.receiver_address].filter(Boolean).join(' · ')) : '');
}

/** Texte prêt à envoyer au client + bouton WhatsApp (numéro du client si connu). */
function clientPack(s, code, exp) {
  const url = C.siteUrl() + '/#/track/' + s.tracking_number;
  let m = 'Bonjour ' + s.customer_name + ',\n\nVotre colis ' + C.siteName() + ' est enregistré.\n\nN° de suivi : ' + s.tracking_number + '\n';
  if (code) m += 'Code de vérification : ' + code + (exp ? " (valable jusqu'au " + new Date(exp).toLocaleDateString('fr-FR', { timeZone: C.timezone() }) + ')' : '') + '\n';
  m += 'Suivez votre colis, ses messages et sa position sur la carte ici : ' + url + "\n\nBesoin d'aide ? WhatsApp +" + C.whatsapp();
  const digits = String(s.customer_phone || '').replace(/\D+/g, '');
  const wa = 'https://wa.me/' + (digits.length >= 8 ? digits : '') + '?text=' + encodeURIComponent(m);
  return [m, [{ text: '📲 Envoyer au client sur WhatsApp', url: wa }]];
}

async function newCode(id, mode, hours) {
  if (mode === 'none') {
    await q("UPDATE shipments SET access_mode='none', access_token_hash=NULL, access_expires_at=NULL, access_used_at=NULL, updated_at=now() WHERE id=$1", [id]);
    return [null, null];
  }
  const code = C.generateAccessCode();
  const exp = (mode === 'temporary' || mode === 'one_time') && hours > 0 ? new Date(Date.now() + hours * 3600 * 1000).toISOString() : null;
  await q('UPDATE shipments SET access_mode=$1, access_token_hash=$2, access_expires_at=$3, access_used_at=NULL, updated_at=now() WHERE id=$4', [mode, C.hashCode(code), exp, id]);
  return [code, exp];
}

/** Enregistre une nouvelle position (carte du client) et l'ajoute à l'historique du parcours. */
async function addPosition(id, label, lat, lng, source, who) {
  await q('UPDATE shipments SET current_location=$1, current_latitude=$2, current_longitude=$3, location_updated_at=now(), updated_at=now() WHERE id=$4', [String(label).slice(0, 160), lat, lng, id]);
  await q('INSERT INTO positions (shipment_id, label, latitude, longitude, source, created_by) VALUES ($1,$2,$3,$4,$5,$6)', [id, String(label).slice(0, 160), lat, lng, source, who]);
}

const HELP =
  '<b>TRANSWORLD DELIVERY - Bot équipe</b>\n\n' +
  '👉 Le plus simple : <b>/liste</b> ou <b>/colis TWD-XXXX-XXXX</b> ouvre un <b>panneau à boutons</b> (position, message, avancement, statut, transport, détails, code, archiver, supprimer).\n\n' +
  '<b>COLIS</b>\n' +
  '<b>/nouveau</b> Client | Ville, Pays origine | Ville, Pays destination | Mode | Poids kg | Téléphone | Code\n<i>Mode</i> : air, mer, terre, rail, express, vehicule · <i>Code</i> : permanent (défaut), unique, temp\nEx : <code>/nouveau Jean Dupont | Shanghai, China | Douala, Cameroon | air | 12 | +237600000000 | permanent</code>\n' +
  '<b>/details</b> TWD-XXXX-XXXX champ=valeur | champ=valeur : ajoute/modifie plusieurs informations (transporteur, reference, service, destinataire, teldest, adresse, assurance, paiement, manutention, poids, dimensions, contenu, type, valeur…)\n' +
  '<b>/modifier</b> TWD-XXXX-XXXX champ valeur : un seul champ (« - » = effacer)\n' +
  '<b>/trajet</b> TWD-XXXX-XXXX Ville, Pays | Ville, Pays : change origine et destination\n' +
  '<b>/code</b> TWD-XXXX-XXXX [permanent|unique|temp|aucun] [heures] : nouveau code (affiché une seule fois)\n' +
  '<b>/info</b> · <b>/historique</b> · <b>/messages</b> TWD-XXXX-XXXX\n' +
  '<b>/eta</b> TWD-XXXX-XXXX AAAA-MM-JJ\n' +
  '<b>/off</b> · <b>/on</b> : couper / réactiver le suivi public · <b>/archiver</b> · <b>/desarchiver</b>\n\n' +
  '<b>VOYAGE (ce que voit le client sur la carte)</b>\n' +
  '<b>/statut</b> TWD-XXXX-XXXX STATUT [lieu] : transit, douane, dedouane, depot, livraison, livre, retard, probleme, recu, traitement…\n' +
  '<b>/progres</b> TWD-XXXX-XXXX 40 (ou +10 / -10) : fait avancer l\'icône ✈️🚢🚚 de l\'origine (0) à la destination (100)\n' +
  '<b>/transport</b> TWD-XXXX-XXXX air|mer|terre|rail|express|vehicule : change l\'icône\n' +
  '<b>/position</b> TWD-XXXX-XXXX Lieu   ou   lat,lng Lieu : position précise · seul, puis 📎 → Position (ou « Position en direct ») : GPS du téléphone\n' +
  '<b>/message</b> TWD-XXXX-XXXX texte : le client le voit sur sa page de suivi (et par email s\'il en a un)\n\n' +
  '<b>NETTOYAGE</b>\n' +
  '<b>/supprimer</b> TWD-XXXX-XXXX : supprime un code (avec confirmation)\n' +
  '<b>/nettoyer</b> [jours] : liste puis supprime d\'un coup les codes archivés, coupés, ou livrés/annulés depuis plus de N jours (30 par défaut), avec confirmation\n\n' +
  '<b>ÉQUIPE</b>\n' +
  '<b>/devis</b> : dernières demandes · <b>/devis</b> ID contacte|ferme|nouveau\n' +
  '<b>/liste</b> · <b>/stats</b> · <b>/journal</b> · <b>/annuler</b> (abandonne une saisie en cours)';

async function handleLocation(msg, edited, chat, who) {
  const loc = msg.location;
  const lat = Number(loc.latitude), lng = Number(loc.longitude);
  if (!isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return;
  const st = await one('SELECT shipment_id FROM bot_state WHERE chat_id = $1 AND expires_at > now()', [chat]);
  if (!st) {
    if (!edited) await C.tgSend(chat, "ℹ️ Pour envoyer une position GPS, tapez d'abord <code>/position TWD-XXXX-XXXX</code>, puis partagez votre position.");
    return;
  }
  const s = await one('SELECT * FROM shipments WHERE id = $1', [st.shipment_id]);
  if (!s) return;
  const last = await one("SELECT label, latitude, longitude, created_at FROM positions WHERE shipment_id = $1 AND source = 'gps' ORDER BY created_at DESC, id DESC LIMIT 1", [s.id]);
  if (edited && last && Date.now() - new Date(last.created_at).getTime() < 60000) return; // position en direct : 1 mise à jour / minute max
  let label;
  if (edited && last && C.haversineKm([lat, lng], [Number(last.latitude), Number(last.longitude)]) < 5) label = last.label;
  else label = (await C.reverseGeocode(lat, lng)) || lat.toFixed(4) + ', ' + lng.toFixed(4);
  await addPosition(s.id, label, lat, lng, 'gps', who);
  if (!edited) await q('UPDATE bot_state SET awaiting = NULL, awaiting_at = NULL WHERE chat_id = $1', [chat]);
  if (!edited) {
    await C.logActivity(who, 'location_update', s.id, '[Telegram: ' + who + '] ' + s.tracking_number + ' GPS ' + label);
    await C.tgSend(chat, '📍 Position GPS enregistrée pour <code>' + esc(s.tracking_number) + '</code> : <b>' + esc(label) + '</b>\nLe client la voit sur sa carte. Avec « Position en direct », la carte se met à jour toutes les minutes.');
  }
}

async function oldShipments(days) {
  return q("SELECT id, tracking_number, customer_name, status, archived, tracking_enabled FROM shipments WHERE archived = TRUE OR tracking_enabled = FALSE OR (status IN ('DELIVERED','CANCELLED') AND updated_at < now() - make_interval(days => $1)) ORDER BY id", [days]);
}

/** Panneau de commande d'un colis : chaque bouton déclenche une action (ou demande la saisie suivante). */
async function sendPanel(chat, s) {
  const id = s.id, b = (text, act, arg) => ({ text, callback_data: 'p|' + id + '|' + act + (arg !== undefined ? '|' + arg : '') });
  return C.tgSend(chat, describe(s), [
    [b('📍 Position', 'pos'), b('💬 Message client', 'msg')],
    [b('⏪ -10%', 'pg', '-10'), b('⏩ +10%', 'pg', '+10'), b('🏁 Arrivé 100%', 'pg', '100')],
    [b('🔄 Statut…', 'stl'), b('🧭 Transport…', 'trl')],
    [b('📅 Date estimée', 'eta'), b('✏️ Détails', 'det')],
    [b('🔑 Nouveau code', 'code'), b(s.tracking_enabled ? '🔴 Couper le suivi' : '🟢 Activer le suivi', 'tog')],
    [b(s.archived ? '♻️ Restaurer' : '🗄 Archiver', 'arc'), b('🗑 Supprimer', 'del')],
  ]);
}

async function setAwait(chat, id, kind) {
  await q("INSERT INTO bot_state (chat_id, shipment_id, expires_at, awaiting, awaiting_at) VALUES ($1,$2, now() + interval '12 hours', $3, now()) ON CONFLICT (chat_id) DO UPDATE SET shipment_id = EXCLUDED.shipment_id, expires_at = EXCLUDED.expires_at, awaiting = EXCLUDED.awaiting, awaiting_at = EXCLUDED.awaiting_at", [chat, id, kind]);
}

const answerCb = (id, text) => C.httpReq('https://api.telegram.org/bot' + C.env('TELEGRAM_TOKEN') + '/answerCallbackQuery', { callback_query_id: id, text: text || undefined }, 4000);

async function handleCallback(cq, chat, from, who) {
  const parts = String(cq.data || '').split('|');
  if (parts[0] === 'x') { // nettoyage groupé confirmé : x|jours|nombre attendu
    const days = parseInt(parts[1], 10), expected = parseInt(parts[2], 10);
    const rows = await oldShipments(days);
    if (!rows.length) return C.tgSend(chat, 'Rien à supprimer (déjà fait ?).');
    if (rows.length > expected) return C.tgSend(chat, '⚠️ La liste a changé (' + rows.length + ' au lieu de ' + expected + '). Relancez <code>/nettoyer ' + days + '</code> pour revoir la liste avant de confirmer.');
    const n = await C.deleteShipments(rows.map((r) => r.id));
    await C.logActivity(who, 'shipments_cleanup', null, '[Telegram: ' + who + '] Deleted ' + n + ' old tracking codes: ' + rows.map((r) => r.tracking_number).join(', '));
    return C.tgSend(chat, '🧹 <b>' + n + ' ancien(s) code(s) supprimé(s).</b>');
  }
  if (parts[0] !== 'p') return;
  const id = parseInt(parts[1], 10), act = parts[2], arg = parts[3];
  if (act === 'none') return C.tgSend(chat, '↩️ Annulé.');
  const s = id ? await one('SELECT * FROM shipments WHERE id = $1', [id]) : null;
  if (!s) return C.tgSend(chat, '❌ Colis introuvable (peut-être déjà supprimé).');
  const no = s.tracking_number, run = (c) => handleCommand(c, chat, from, who);
  const back = [[{ text: '📋 Panneau du colis', callback_data: 'p|' + id + '|back' }]];
  switch (act) {
    case 'back': return sendPanel(chat, s);
    case 'pg': return run('/progres ' + no + ' ' + arg);
    case 'st': return run('/statut ' + no + ' ' + arg);
    case 'tr': return run('/transport ' + no + ' ' + arg);
    case 'code': return C.tgSend(chat, '🔑 Générer un <b>nouveau code permanent</b> pour <code>' + esc(no) + '</code> ?\nL\'ancien code ne fonctionnera plus : pensez à envoyer le nouveau au client.', [[{ text: '🔑 Oui, générer', callback_data: 'p|' + id + '|codey' }, { text: 'Annuler', callback_data: 'p|' + id + '|back' }]]);
    case 'codey': return run('/code ' + no + ' permanent');
    case 'tog': return run((s.tracking_enabled ? '/off ' : '/on ') + no);
    case 'arc': return run((s.archived ? '/desarchiver ' : '/archiver ') + no);
    case 'del': return run('/supprimer ' + no);
    case 'dely': {
      const n = await C.deleteShipments([id]);
      await C.logActivity(who, 'shipment_delete', null, '[Telegram: ' + who + '] Deleted tracking code ' + no + ' (' + s.customer_name + ')');
      return C.tgSend(chat, n ? '🗑 <code>' + esc(no) + '</code> supprimé définitivement.' : '❌ Suppression impossible.');
    }
    case 'stl': {
      const keys = Object.keys(C.STATUSES), rows = [];
      for (let k = 0; k < keys.length; k += 2) rows.push(keys.slice(k, k + 2).map((c) => ({ text: C.statusLabel(c), callback_data: 'p|' + id + '|st|' + c })));
      return C.tgSend(chat, '🔄 Nouveau statut pour <code>' + esc(no) + '</code> (actuel : <b>' + esc(C.statusLabel(s.status)) + '</b>).\nPour ajouter un lieu : <code>/statut ' + esc(no) + ' transit Dubai</code>', rows);
    }
    case 'trl': return C.tgSend(chat, '🧭 Choisissez l\'icône de transport vue par le client :', [
      [{ text: '✈️ Avion', callback_data: 'p|' + id + '|tr|air' }, { text: '🚢 Bateau', callback_data: 'p|' + id + '|tr|mer' }, { text: '🚚 Camion', callback_data: 'p|' + id + '|tr|terre' }],
      [{ text: '🚆 Train', callback_data: 'p|' + id + '|tr|rail' }, { text: '⚡ Express', callback_data: 'p|' + id + '|tr|express' }, { text: '🚗 Véhicule', callback_data: 'p|' + id + '|tr|vehicule' }]]);
    case 'pos': await setAwait(chat, id, 'pos'); return C.tgSend(chat, '📍 <code>' + esc(no) + '</code> : envoyez maintenant le lieu (ex. <code>Dubai Hub</code> ou <code>25.2,55.3 Dubai Hub</code>) ou partagez votre position GPS (📎 → Position). /annuler pour abandonner.');
    case 'msg': await setAwait(chat, id, 'msg'); return C.tgSend(chat, '💬 <code>' + esc(no) + '</code> : écrivez maintenant le message pour le client (il le verra sur sa page de suivi). /annuler pour abandonner.');
    case 'eta': await setAwait(chat, id, 'eta'); return C.tgSend(chat, '📅 <code>' + esc(no) + '</code> : envoyez la date de livraison estimée au format <code>AAAA-MM-JJ</code>. /annuler pour abandonner.');
    case 'det': await setAwait(chat, id, 'det'); return C.tgSend(chat, '✏️ <code>' + esc(no) + '</code> : envoyez les informations à ajouter ou modifier, séparées par « | » :\n<code>transporteur=MSC Aurora | reference=VOY 245E | service=Express | destinataire=Marie | teldest=+237600000000 | adresse=Rue 1.2, Douala | assurance=oui | paiement=paye | fragile=Fragile | poids=15 | dimensions=40x30x20 | contenu=Vêtements</code>\nChamps : ' + esc(Object.keys(FIELDS).join(', ')) + '. /annuler pour abandonner.');
    default: return sendPanel(chat, s);
  }
}

/** Texte libre envoyé après un bouton (message, lieu, date, détails) : exécuté comme la commande correspondante. */
async function handleAwaited(text, chat, from, who) {
  const st = await one("SELECT b.shipment_id, b.awaiting, s.tracking_number FROM bot_state b JOIN shipments s ON s.id = b.shipment_id WHERE b.chat_id = $1 AND b.awaiting IS NOT NULL AND b.awaiting_at > now() - interval '10 minutes'", [chat]);
  if (!st) return false;
  await q('UPDATE bot_state SET awaiting = NULL, awaiting_at = NULL WHERE chat_id = $1', [chat]);
  const cmd = { pos: '/position ', msg: '/message ', eta: '/eta ', det: '/details ' }[st.awaiting];
  if (!cmd) return false;
  await handleCommand(cmd + st.tracking_number + ' ' + text, chat, from, who);
  return true;
}

async function handleCommand(text, chat, from, who) {
  if ((await C.rateCount('tg:' + from, 60)) >= 40) return C.tgSend(chat, 'Trop de commandes. Attendez une minute.');
  await C.rateHit('tg:' + from);

  const m = text.match(/^(\S+)\s*([\s\S]*)$/);
  const cmd = m[1].toLowerCase().replace(/@.*$/, '');
  const arg = m[2].trim();
  const tok = arg === '' ? [] : arg.split(/\s+/);
  const tag = '[Telegram: ' + who + '] ';
  const bad = (usage) => C.tgSend(chat, '❌ ' + usage);

  if (cmd === '/start' || cmd === '/aide' || cmd === '/help') return C.tgSend(chat, 'Bonjour ' + esc(who) + ' 👋\n\n' + HELP);

  if (cmd === '/nouveau') {
    const f = arg.split('|').map((x) => x.trim());
    if (f.length < 4 || !f[0]) return bad('Format : <code>/nouveau Client | Ville, Pays | Ville, Pays | Mode | Poids | Téléphone | Code</code>\nTapez /aide pour un exemple.');
    const o = f[1].split(/,(.+)/).map((x) => x.trim()), d = f[2].split(/,(.+)/).map((x) => x.trim());
    if (!o[0] || !o[1] || !d[0] || !d[1]) return bad('Origine et destination doivent être au format « Ville, Pays ».');
    const method = METHODS[f[3].toLowerCase()];
    if (!method) return bad('Mode inconnu. Utilisez : air, mer, terre, rail, express, vehicule.');
    const weight = f[4] && isNum(f[4]) ? toNum(f[4]) : null;
    const phone = f[5] ? f[5].slice(0, 40) : null;
    const mode = f[6] ? CODE_MODES[f[6].toLowerCase()] : 'permanent';
    if (!mode) return bad('Type de code inconnu : permanent, unique ou temp.');
    const oc = await C.geocode(f[1]);
    const dc = await C.geocode(f[2]);
    const no = await C.generateTracking();
    let code = null, hash = null, exp = null;
    if (mode !== 'none') {
      code = C.generateAccessCode();
      hash = C.hashCode(code);
      if (mode === 'temporary' || mode === 'one_time') exp = new Date(Date.now() + 72 * 3600 * 1000).toISOString();
    }
    const rows = await q(
      `INSERT INTO shipments (tracking_number, access_mode, access_token_hash, access_expires_at, customer_name, customer_phone,
        origin_country, origin_city, origin_latitude, origin_longitude, destination_country, destination_city, destination_latitude, destination_longitude,
        current_location, current_latitude, current_longitude, location_updated_at, shipping_method, weight, status, progress, shipment_date, created_by, transport_mode)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,'CREATED',10,$21,$22,$23) RETURNING *`,
      [no, mode, hash, exp, f[0].slice(0, 150), phone, o[1].slice(0, 80), o[0].slice(0, 80), oc ? oc[0] : null, oc ? oc[1] : null, d[1].slice(0, 80), d[0].slice(0, 80), dc ? dc[0] : null, dc ? dc[1] : null,
        o[0].slice(0, 160), oc ? oc[0] : null, oc ? oc[1] : null, oc ? new Date().toISOString() : null, method, weight, C.todayStr(), who, C.METHOD_TO_MODE[method]]
    );
    const s = rows[0];
    await q("INSERT INTO tracking_events (shipment_id, status, location, description, created_by) VALUES ($1,'CREATED',$2,'Shipment registered in our logistics system.',$3)", [s.id, o[0], who]);
    if (oc) await q("INSERT INTO positions (shipment_id, label, latitude, longitude, source, created_by) VALUES ($1,$2,$3,$4,'status',$5)", [s.id, o[0], oc[0], oc[1], who]);
    await C.logActivity(who, 'shipment_create', s.id, tag + 'Created shipment ' + no);
    const [msg, btn] = clientPack(s, code, exp);
    return C.tgSend(chat, '✅ <b>Colis créé</b>\n📦 <code>' + esc(no) + '</code>' +
      (code ? '\n🔑 Code : <code>' + esc(code) + '</code> (' + esc(mode) + ', affiché une seule fois)' : '\n🔓 Sans code : le numéro suffit') +
      (oc && dc ? '' : '\n⚠️ Une ville n\'a pas été géolocalisée : la carte sera incomplète. Utilisez /position pour la corriger.') +
      '\n\n<pre>' + esc(msg) + '</pre>', [btn, [{ text: '📋 Ouvrir le panneau du colis', callback_data: 'p|' + s.id + '|back' }]]);
  }

  if (cmd === '/code') {
    const s = await findShip(tok[0]);
    if (!s) return bad('Colis introuvable. Format : <code>/code TWD-XXXX-XXXX [permanent|unique|temp|aucun] [heures]</code>');
    const mode = tok[1] ? CODE_MODES[tok[1].toLowerCase()] : 'permanent';
    if (!mode) return bad('Type : permanent, unique, temp ou aucun.');
    const hours = tok[2] && isNum(tok[2]) ? toNum(tok[2]) : 24;
    const [code, exp] = await newCode(s.id, mode, hours);
    await C.logActivity(who, code ? 'code_generate' : 'code_remove', s.id, tag + (code ? 'New ' + mode + ' access code for ' : 'Code removed for ') + s.tracking_number);
    const [msg, btn] = clientPack(s, code, exp);
    return C.tgSend(chat, code
      ? '🔑 <b>Nouveau code</b> pour <code>' + esc(s.tracking_number) + '</code>\n<code>' + esc(code) + '</code> (' + esc(mode) + (exp ? ', expire ' + esc(C.fmtDate(exp)) : '') + ')\nAffiché une seule fois.\n\n<pre>' + esc(msg) + '</pre>'
      : '🔓 Code retiré pour <code>' + esc(s.tracking_number) + '</code> : le numéro suffit maintenant.', code ? btn : undefined);
  }

  if (cmd === '/statut' || cmd === '/status') {
    const s = await findShip(tok[0]);
    const st = tok[1] ? resolveStatus(tok[1]) : null;
    if (!s || !st) return bad('Format : <code>/statut TWD-XXXX-XXXX transit Dubai</code>. Statut inconnu ou colis introuvable (tapez /aide).');
    const loc = tok.slice(2).join(' ').trim();
    const coords = loc ? await C.geocode(loc) : null;
    const prog = C.progressFor(st, s.progress);
    await q('INSERT INTO tracking_events (shipment_id, status, location, latitude, longitude, description, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7)',
      [s.id, st, loc || null, coords ? coords[0] : null, coords ? coords[1] : null, C.statusLabel(st) + (loc ? ' - ' + loc : '') + '.', who]);
    await q('UPDATE shipments SET status=$1, progress=$2, delivered_at = CASE WHEN $4::boolean THEN now() ELSE delivered_at END, updated_at=now() WHERE id=$3', [st, prog, s.id, st === 'DELIVERED']);
    if (loc && coords) await addPosition(s.id, loc, coords[0], coords[1], 'status', who);
    else if (loc) await q('UPDATE shipments SET current_location=$1, location_updated_at=now() WHERE id=$2', [loc.slice(0, 160), s.id]);
    await C.logActivity(who, 'status_update', s.id, tag + s.tracking_number + ' | Old status: ' + s.status + ' | New status: ' + st + (loc ? ' | ' + loc : ''));
    if (MAIL_ON.includes(st)) await C.notifyEmail({ ...s, status: st }, C.statusLabel(st), 'Status update for your shipment: ' + C.statusLabel(st) + (loc ? ' - ' + loc : '') + '.');
    return C.tgSend(chat, '✅ <code>' + esc(s.tracking_number) + '</code> → <b>' + esc(C.statusLabel(st)) + '</b> (' + prog + '%)' +
      (loc ? '\n📍 ' + esc(loc) + (coords ? '' : "\n⚠️ Lieu non géolocalisé : la carte garde l'ancienne position. Utilisez /position avec lat,lng.") : ''));
  }

  if (cmd === '/position') {
    const s = await findShip(tok[0]);
    if (!s) return bad('Format : <code>/position TWD-XXXX-XXXX Dubai Hub</code>, <code>/position TWD-XXXX-XXXX 25.2048,55.2708 Dubai Hub</code>, ou seul pour envoyer votre position GPS.');
    if (tok.length === 1) {
      await q('INSERT INTO bot_state (chat_id, shipment_id, expires_at) VALUES ($1,$2, now() + interval \'12 hours\') ON CONFLICT (chat_id) DO UPDATE SET shipment_id = EXCLUDED.shipment_id, expires_at = EXCLUDED.expires_at', [chat, s.id]);
      return C.tgSend(chat, '📍 Colis <code>' + esc(s.tracking_number) + '</code> sélectionné pour 12 h.\nTouchez 📎 → <b>Position</b> et envoyez votre position (ou « Partager ma position en direct » : la carte du client se met à jour toute seule).');
    }
    let coords, name;
    const mm = tok[1].match(/^(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)$/);
    if (mm) {
      coords = [parseFloat(mm[1]), parseFloat(mm[2])];
      name = tok.slice(2).join(' ').trim();
      if (Math.abs(coords[0]) > 90 || Math.abs(coords[1]) > 180 || !name) return bad('Coordonnées invalides ou nom du lieu manquant.');
    } else {
      name = tok.slice(1).join(' ').trim();
      coords = await C.geocode(name);
      if (!coords) return bad('Lieu introuvable. Donnez les coordonnées : <code>/position TWD-... lat,lng Nom</code>');
    }
    await addPosition(s.id, name, coords[0], coords[1], 'manual', who);
    await C.logActivity(who, 'location_update', s.id, tag + 'Live location: ' + name + ' (' + coords[0] + ', ' + coords[1] + ')');
    return C.tgSend(chat, '📍 Position mise à jour : <b>' + esc(name) + '</b> (' + coords[0] + ', ' + coords[1] + ')\nLe client la voit sur sa carte.');
  }

  if (cmd === '/message' || cmd === '/msg') {
    const mt = arg.match(/^(\S+)\s+([\s\S]+)$/);
    const s = mt ? await findShip(mt[1]) : null;
    if (!s) return bad('Format : <code>/message TWD-XXXX-XXXX Votre colis est arrivé à Dubaï, départ demain.</code>');
    const body = mt[2].trim().slice(0, 1000);
    await q('INSERT INTO messages (shipment_id, body, author) VALUES ($1,$2,$3)', [s.id, body, who]);
    await q('UPDATE shipments SET updated_at=now() WHERE id=$1', [s.id]);
    await C.logActivity(who, 'message_send', s.id, tag + s.tracking_number + ' | message: ' + body.slice(0, 120));
    await C.notifyEmail(s, 'New message', body);
    return C.tgSend(chat, '💬 Message publié pour <code>' + esc(s.tracking_number) + '</code>. Le client le voit sur sa page de suivi' + (s.customer_email ? ' (et reçoit un email).' : '.') + (s.tracking_enabled ? '' : '\n⚠️ Le suivi public est coupé (/on pour le réactiver).'));
  }

  if (cmd === '/messages') {
    const s = await findShip(tok[0]);
    if (!s) return bad('Format : <code>/messages TWD-XXXX-XXXX</code>');
    const rows = await q('SELECT body, author, created_at FROM messages WHERE shipment_id = $1 ORDER BY created_at DESC, id DESC LIMIT 10', [s.id]);
    return C.tgSend(chat, '<b>Messages</b> <code>' + esc(s.tracking_number) + '</code>\n' + (rows.length ? rows.map((r) => '\n' + esc(C.fmtDate(r.created_at)) + ' (' + esc(r.author || '-') + ') : ' + esc(r.body)).join('') : '\nAucun message.'));
  }

  if (cmd === '/eta') {
    const s = await findShip(tok[0]);
    if (!s || !/^\d{4}-\d{2}-\d{2}$/.test(tok[1] || '')) return bad('Format : <code>/eta TWD-XXXX-XXXX 2026-11-10</code>');
    await q('UPDATE shipments SET estimated_delivery=$1, updated_at=now() WHERE id=$2', [tok[1], s.id]);
    await C.logActivity(who, 'eta_update', s.id, tag + 'Estimated delivery: ' + (s.estimated_delivery || '-') + ' -> ' + tok[1]);
    await C.notifyEmail(s, 'Shipment Updated', 'The estimated delivery date of your shipment was updated to ' + tok[1] + '.');
    return C.tgSend(chat, '📅 Livraison estimée : <b>' + esc(tok[1]) + '</b>');
  }

  if (cmd === '/info') {
    const s = await findShip(tok[0]);
    return s ? sendPanel(chat, s) : C.tgSend(chat, '❌ Colis introuvable. Format : <code>/info TWD-XXXX-XXXX</code>');
  }

  if (cmd === '/liste') {
    const rows = await q('SELECT id, tracking_number, customer_name, status FROM shipments WHERE archived = FALSE ORDER BY id DESC LIMIT 10');
    return C.tgSend(chat, rows.length ? '<b>10 derniers colis</b> : touchez un colis pour ouvrir son panneau' : 'Aucun colis.',
      rows.length ? rows.map((r) => [{ text: r.tracking_number + ' · ' + r.customer_name.slice(0, 18) + ' · ' + C.statusLabel(r.status), callback_data: 'p|' + r.id + '|back' }]) : undefined);
  }

  if (cmd === '/off' || cmd === '/on') {
    const s = await findShip(tok[0]);
    if (!s) return bad('Colis introuvable.');
    const on = cmd === '/on';
    await q('UPDATE shipments SET tracking_enabled=$1, updated_at=now() WHERE id=$2', [on, s.id]);
    await C.logActivity(who, 'toggle_tracking', s.id, tag + (on ? 'Enabled' : 'Disabled') + ' public tracking for ' + s.tracking_number);
    return C.tgSend(chat, (on ? '🟢 Suivi public activé : ' : '🔴 Suivi public coupé : ') + '<code>' + esc(s.tracking_number) + '</code>');
  }

  if (cmd === '/archiver' || cmd === '/desarchiver') {
    const s = await findShip(tok[0]);
    if (!s) return bad('Colis introuvable.');
    const ar = cmd === '/archiver';
    await q('UPDATE shipments SET archived=$1, updated_at=now() WHERE id=$2', [ar, s.id]);
    await C.logActivity(who, ar ? 'shipment_archive' : 'shipment_unarchive', s.id, tag + s.tracking_number);
    return C.tgSend(chat, (ar ? '🗄 Archivé (suivi public coupé) : ' : '♻️ Restauré : ') + '<code>' + esc(s.tracking_number) + '</code>');
  }

  if (cmd === '/modifier') {
    const s = await findShip(tok[0]);
    if (!s || !tok[1] || tok.length < 3) return bad('Format : <code>/modifier TWD-XXXX-XXXX poids 15</code> (« - » efface un champ facultatif).\nChamps : ' + esc(Object.keys(FIELDS).join(', ')) + '.\nPlusieurs d\'un coup : <code>/details TWD-XXXX-XXXX transporteur=MSC | reference=VOY245 | assurance=oui</code>');
    const r = await applyFields(s, [[tok[1], tok.slice(2).join(' ')]], who);
    return C.tgSend(chat, r.errs.length ? '❌ ' + esc(r.errs[0]) : '✅ <code>' + esc(s.tracking_number) + '</code> : ' + esc(tok[1].toLowerCase()) + ' mis à jour (visible sur la page client si c\'est une information publique).');
  }

  if (cmd === '/details' || cmd === '/détails') {
    const s = await findShip(tok[0]);
    const body = arg.replace(/^\S+\s*/, '');
    const pairs = body.split('|').map((x) => x.trim()).filter(Boolean).map((x) => { const k = x.search(/[=:]/); return k > 0 ? [x.slice(0, k).trim(), x.slice(k + 1).trim()] : [x, '']; });
    if (!s || !pairs.length) return bad('Format : <code>/details TWD-XXXX-XXXX transporteur=MSC Aurora | reference=VOY 245E | service=Express | destinataire=Marie Kamga | teldest=+237600000000 | adresse=Rue 1.2, Douala | assurance=oui | paiement=paye | fragile=Fragile, ne pas empiler | poids=15 | dimensions=40x30x20 | contenu=Vêtements</code>\nChamps : ' + esc(Object.keys(FIELDS).join(', ')));
    const r = await applyFields(s, pairs, who);
    return C.tgSend(chat, (r.done.length ? '✅ <code>' + esc(s.tracking_number) + '</code> mis à jour : ' + esc(r.done.join(', ')) : '') + (r.errs.length ? '\n❌ ' + r.errs.map(esc).join('\n❌ ') : ''), r.done.length ? [[{ text: '📋 Ouvrir le panneau', callback_data: 'p|' + s.id + '|back' }]] : undefined);
  }

  if (cmd === '/trajet') {
    const s = await findShip(tok[0]);
    const f = arg.replace(/^\S+\s*/, '').split('|').map((x) => x.trim());
    if (!s || f.length < 2 || !f[0] || !f[1]) return bad('Format : <code>/trajet TWD-XXXX-XXXX Shanghai, China | Douala, Cameroon</code> (origine | destination, « Ville, Pays »).');
    const o = f[0].split(/,(.+)/).map((x) => x.trim()), d = f[1].split(/,(.+)/).map((x) => x.trim());
    if (!o[0] || !o[1] || !d[0] || !d[1]) return bad('Origine et destination doivent être au format « Ville, Pays ».');
    const oc = await C.geocode(f[0]), dc = await C.geocode(f[1]);
    await q('UPDATE shipments SET origin_city=$1, origin_country=$2, origin_latitude=$3, origin_longitude=$4, destination_city=$5, destination_country=$6, destination_latitude=$7, destination_longitude=$8, updated_at=now() WHERE id=$9',
      [o[0].slice(0, 80), o[1].slice(0, 80), oc ? oc[0] : null, oc ? oc[1] : null, d[0].slice(0, 80), d[1].slice(0, 80), dc ? dc[0] : null, dc ? dc[1] : null, s.id]);
    await C.logActivity(who, 'route_update', s.id, tag + s.tracking_number + ' | route: ' + f[0] + ' -> ' + f[1]);
    return C.tgSend(chat, '🛣 Trajet mis à jour : <b>' + esc(f[0]) + '</b> → <b>' + esc(f[1]) + '</b>' + (oc && dc ? '' : '\n⚠️ Une ville n\'a pas été géolocalisée : la carte sera incomplète.'));
  }

  if (cmd === '/progres' || cmd === '/progrès' || cmd === '/avance') {
    const s = await findShip(tok[0]);
    const mm = (tok[1] || '').match(/^([+-]?)(\d{1,3})\s*%?$/);
    if (!s || !mm) return bad('Format : <code>/progres TWD-XXXX-XXXX 40</code> (ou <code>+10</code> / <code>-10</code>) : fait avancer l\'icône du transport sur la carte du client, de l\'origine (0) à la destination (100).');
    let pct = parseInt(mm[2], 10);
    if (mm[1] === '+') pct = Number(s.progress) + pct; else if (mm[1] === '-') pct = Number(s.progress) - pct;
    pct = Math.max(0, Math.min(100, pct));
    const o = [C.num(s.origin_latitude), C.num(s.origin_longitude)], d = [C.num(s.destination_latitude), C.num(s.destination_longitude)];
    const ok = (p) => p[0] !== null && p[1] !== null;
    await q('UPDATE shipments SET progress=$1, updated_at=now() WHERE id=$2', [pct, s.id]);
    let line = '';
    if (ok(o) && ok(d)) {
      const pt = C.interpolate(o, d, pct / 100);
      const label = pct <= 0 ? s.origin_city : pct >= 100 ? s.destination_city : 'In transit · ' + pct + '% of the route';
      await addPosition(s.id, label, pt[0], pt[1], 'manual', who);
      line = '\n📍 ' + esc(label) + ' (' + pt[0] + ', ' + pt[1] + ')';
    } else line = '\n⚠️ Origine ou destination non géolocalisée : seule la barre de progression bouge. Corrigez avec /trajet.';
    await C.logActivity(who, 'progress_update', s.id, tag + s.tracking_number + ' | progress ' + s.progress + '% -> ' + pct + '%');
    return C.tgSend(chat, MODE_ICON[C.modeOf(s)] + ' <code>' + esc(s.tracking_number) + '</code> → <b>' + pct + '%</b> du trajet' + line + '\nLe client voit l\'icône avancer sur sa carte.',
      [[{ text: '⏪ -10%', callback_data: 'p|' + s.id + '|pg|-10' }, { text: '⏩ +10%', callback_data: 'p|' + s.id + '|pg|+10' }, { text: '🏁 100%', callback_data: 'p|' + s.id + '|pg|100' }]]);
  }

  if (cmd === '/transport') {
    const s = await findShip(tok[0]);
    const method = tok[1] ? METHODS[tok[1].toLowerCase()] : null;
    if (!s || !method) return bad('Format : <code>/transport TWD-XXXX-XXXX air</code> (air, mer, terre, rail, express, vehicule) : change l\'icône (✈️ 🚢 🚚 🚆 ⚡ 🚗) vue par le client.');
    await q('UPDATE shipments SET shipping_method=$1, transport_mode=$2, updated_at=now() WHERE id=$3', [method, C.METHOD_TO_MODE[method], s.id]);
    await C.logActivity(who, 'transport_update', s.id, tag + s.tracking_number + ' | transport: ' + method);
    return C.tgSend(chat, MODE_ICON[C.METHOD_TO_MODE[method]] + ' Transport : <b>' + esc(method) + '</b> pour <code>' + esc(s.tracking_number) + '</code>.');
  }

  if (cmd === '/colis' || cmd === '/panneau') {
    const s = await findShip(tok[0]);
    if (!s) return bad('Format : <code>/colis TWD-XXXX-XXXX</code> : ouvre le panneau de commande du colis (boutons).');
    return sendPanel(chat, s);
  }

  if (cmd === '/supprimer') {
    const s = await findShip(tok[0]);
    if (!s) return bad('Format : <code>/supprimer TWD-XXXX-XXXX</code> : supprime définitivement un ancien code de suivi et tout son historique.');
    return C.tgSend(chat, '⚠️ <b>Supprimer définitivement ?</b>\n' + describe(s).split('\n').slice(0, 4).join('\n') + '\n\nLe code, l\'historique, les positions et les messages seront effacés. Le client ne pourra plus le consulter. <b>Action irréversible.</b>',
      [[{ text: '🗑 Oui, supprimer', callback_data: 'p|' + s.id + '|dely' }, { text: 'Annuler', callback_data: 'p|' + s.id + '|back' }]]);
  }

  if (cmd === '/nettoyer') {
    const days = tok[0] && /^\d{1,4}$/.test(tok[0]) ? parseInt(tok[0], 10) : 30;
    const rows = await oldShipments(days);
    if (!rows.length) return C.tgSend(chat, '✅ Rien à nettoyer : aucun code archivé, coupé, ni colis livré/annulé depuis plus de ' + days + ' jour(s).');
    return C.tgSend(chat, '🧹 <b>' + rows.length + ' ancien(s) code(s) à supprimer</b>\n<i>Archivés, suivi coupé (/off), ou livrés/annulés depuis plus de ' + days + ' jour(s).</i>\n' +
      rows.slice(0, 25).map((r) => '\n<code>' + esc(r.tracking_number) + '</code> ' + esc(r.customer_name) + ' · ' + esc(C.statusLabel(r.status)) + (r.archived ? ' · archivé' : r.tracking_enabled ? '' : ' · coupé')).join('') + (rows.length > 25 ? '\n… et ' + (rows.length - 25) + ' autre(s)' : '') +
      '\n\n<b>Suppression définitive, irréversible.</b>', [[{ text: '🗑 Tout supprimer (' + rows.length + ')', callback_data: 'x|' + days + '|' + rows.length }, { text: 'Annuler', callback_data: 'p|0|none' }]]);
  }

  if (cmd === '/annuler') {
    await q('UPDATE bot_state SET awaiting = NULL, awaiting_at = NULL WHERE chat_id = $1', [chat]);
    return C.tgSend(chat, '↩️ Saisie annulée.');
  }

  if (cmd === '/historique') {
    const s = await findShip(tok[0]);
    if (!s) return bad('Colis introuvable. Format : <code>/historique TWD-XXXX-XXXX</code>');
    const ev = await q('SELECT status, location, event_date FROM tracking_events WHERE shipment_id = $1 ORDER BY event_date DESC, id DESC LIMIT 10', [s.id]);
    return C.tgSend(chat, '<b>Historique</b> <code>' + esc(s.tracking_number) + '</code>\n' + ev.map((e) => '\n' + esc(C.fmtDate(e.event_date)) + ' - ' + esc(C.statusLabel(e.status)) + (e.location ? ' (' + esc(e.location) + ')' : '')).join(''));
  }

  if (cmd === '/devis') {
    const id = tok[0] && /^\d+$/.test(tok[0]) ? parseInt(tok[0], 10) : null;
    if (id !== null && tok[1]) {
      const st = { contacte: 'contacted', contacted: 'contacted', ferme: 'closed', closed: 'closed', nouveau: 'new', new: 'new' }[tok[1].toLowerCase()];
      if (!st) return bad('Statut : contacte, ferme ou nouveau.');
      const r = await q('UPDATE quotes SET status=$1 WHERE id=$2 RETURNING id', [st, id]);
      if (!r.length) return bad('Demande #' + id + ' introuvable.');
      await C.logActivity(who, 'quote_status', null, tag + 'Quote #' + id + ' -> ' + st);
      return C.tgSend(chat, '✅ Demande #' + id + ' → ' + esc(st));
    }
    const rows = id !== null
      ? await q('SELECT * FROM quotes WHERE id = $1', [id])
      : await q('SELECT * FROM quotes ORDER BY (status = \'new\') DESC, id DESC LIMIT 8');
    if (!rows.length) return C.tgSend(chat, 'Aucune demande.');
    return C.tgSend(chat, '<b>Demandes</b>\n' + rows.map((r) => '\n<b>#' + r.id + '</b> [' + esc(r.status) + '] ' + esc(r.kind) + ' - ' + esc(r.name) + ' · ' + esc(r.phone || r.email || '') +
      (r.origin || r.destination ? '\n   ' + esc(r.origin || '?') + ' → ' + esc(r.destination || '?') : '') + (r.cargo ? '\n   ' + esc(r.cargo) : '') + (r.message ? '\n   ' + esc(r.message.slice(0, 160)) : '') + '\n   ' + esc(C.fmtDate(r.created_at))).join('') + '\n\n<i>/devis ID contacte|ferme|nouveau</i>');
  }

  if (cmd === '/stats') {
    const [byStatus, qn, mn, tn] = await Promise.all([
      q('SELECT status, count(*)::int AS n FROM shipments WHERE archived = FALSE GROUP BY status ORDER BY n DESC'),
      one("SELECT count(*)::int AS n FROM quotes WHERE status = 'new'"),
      one("SELECT count(*)::int AS n FROM messages WHERE created_at > now() - interval '24 hours'"),
      one('SELECT count(*)::int AS n FROM shipments WHERE archived = FALSE'),
    ]);
    return C.tgSend(chat, '<b>Statistiques</b>\n\n📦 Colis actifs : ' + tn.n + '\n' + byStatus.map((r) => '• ' + esc(C.statusLabel(r.status)) + ' : ' + r.n).join('\n') + '\n\n📩 Demandes nouvelles : ' + qn.n + '\n💬 Messages clients (24 h) : ' + mn.n);
  }

  if (cmd === '/journal') {
    const rows = await q('SELECT l.actor, l.action, l.description, l.created_at FROM admin_activity_logs l ORDER BY l.id DESC LIMIT 10');
    return C.tgSend(chat, '<b>Journal (10 derniers)</b>\n' + (rows.length ? rows.map((r) => '\n' + esc(C.fmtDate(r.created_at)) + ' · ' + esc(r.actor || '-') + ' · ' + esc(r.action) + '\n   ' + esc((r.description || '').replace(/^\[Telegram: [^\]]*\]\s*/, ''))).join('') : '\nVide.'));
  }

  return C.tgSend(chat, 'Commande inconnue.\n\n' + HELP);
}

module.exports = async (req, res) => {
  const plain = (code, body) => { res.statusCode = code; res.setHeader('Content-Type', 'text/plain'); res.end(body || ''); };
  if (req.method !== 'POST') return plain(405);

  const secret = C.env('TELEGRAM_SECRET');
  const given = String(req.headers['x-telegram-bot-api-secret-token'] || '');
  const a = Buffer.from(secret), b = Buffer.from(given);
  if (!C.env('TELEGRAM_TOKEN') || !secret || a.length !== b.length || !crypto.timingSafeEqual(a, b)) return plain(403);

  const upd = C.readJson(req);
  const cq = upd && upd.callback_query;
  const edited = !!(upd && upd.edited_message && !upd.message);
  const msg = cq ? cq.message : upd && (upd.message || upd.edited_message);
  if (!msg || !msg.chat || msg.chat.type !== 'private' || (!cq && !msg.text && !msg.location)) return plain(200, 'ok');

  const from = Number((cq ? cq.from : msg.from) && (cq ? cq.from : msg.from).id) || 0;
  const chat = Number(msg.chat.id);
  let who = '';
  try {
    const members = C.team();
    if (!members[from]) {
      console.error('[TWD telegram] unauthorized user ' + from);
      if (cq) await answerCb(cq.id, 'Accès refusé');
      else if (!edited) await C.tgSend(chat, '⛔ Accès refusé. Ce bot est réservé à l\'équipe TRANSWORLD DELIVERY.\nVotre ID Telegram : <code>' + from + '</code>');
      return plain(200, 'ok');
    }
    who = members[from];

    // Anti-doublon (Telegram renvoie parfois la même mise à jour)
    if (upd.update_id !== undefined) {
      const fresh = await q('INSERT INTO tg_updates (update_id) VALUES ($1) ON CONFLICT DO NOTHING RETURNING update_id', [upd.update_id]);
      if (!fresh.length) return plain(200, 'ok');
    }

    if (cq) {
      await answerCb(cq.id);
      if ((await C.rateCount('tg:' + from, 60)) >= 60) await C.tgSend(chat, 'Trop d\'actions. Attendez une minute.');
      else { await C.rateHit('tg:' + from); await handleCallback(cq, chat, from, who); }
    } else if (msg.location) await handleLocation(msg, edited, chat, who);
    else if (!edited) {
      const text = String(msg.text).trim();
      if (text !== '' && text[0] !== '/') { if (!(await handleAwaited(text, chat, from, who))) await C.tgSend(chat, HELP); }
      else if (text === '') await C.tgSend(chat, HELP);
      else await handleCommand(text, chat, from, who);
    }
  } catch (e) {
    console.error('[TWD telegram]', e.message);
    if (!edited) await C.tgSend(chat, '⚠️ Erreur serveur. L\'action a peut-être échoué : vérifiez avec /info puis réessayez.');
  }
  return plain(200, 'ok');
};
