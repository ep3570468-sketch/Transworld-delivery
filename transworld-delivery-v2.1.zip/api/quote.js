'use strict';
// POST devis / contact -> base de données + alerte Telegram à l'équipe
const C = require('./_lib/core');

const clean = (v, max) => String(v === undefined || v === null ? '' : v).replace(/<[^>]*>/g, '').trim().slice(0, max);

module.exports = async (req, res) => {
  if (req.method !== 'POST') return C.send(res, 405, { error: 'method_not_allowed' });
  const inp = C.readJson(req);
  if (!inp) return C.send(res, 400, { error: 'bad_request' });
  if (inp.website) return C.send(res, 200, { ok: true }); // honeypot anti-spam

  try {
    const ip = C.clientIp(req);
    if ((await C.rateCount('quote:' + ip, 3600)) >= 8) return C.send(res, 429, { error: 'rate_limited', message: 'Too many requests. Please try again later.' });

    const kind = inp.kind === 'contact' ? 'contact' : 'quote';
    const name = clean(inp.name, 150), email = clean(inp.email, 190), phone = clean(inp.phone, 40);
    if (!name || (!phone && !email)) return C.send(res, 422, { error: 'validation', message: 'Name and phone or email are required.' });
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return C.send(res, 422, { error: 'validation', message: 'Invalid email address.' });

    await C.rateHit('quote:' + ip);
    const rows = await C.q(
      'INSERT INTO quotes (kind, name, email, phone, origin, destination, cargo, weight, shipping_method, message, ip_address) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id',
      [kind, name, email || null, phone || null, clean(inp.origin, 120), clean(inp.destination, 120), clean(inp.cargo, 200), clean(inp.weight, 60), clean(inp.mode || inp.shipping_method, 40), clean(inp.message, 2000), ip]
    );
    const e = C.esc;
    await C.tgAlert('📩 <b>Nouvelle demande (' + kind + ') #' + rows[0].id + '</b>\n' + e(name) + ' · ' + e(phone || email) + '\n' + e(inp.origin || '') + ' → ' + e(inp.destination || '') + '\n' + e(clean(inp.cargo || inp.message || '', 200)) + '\n\n<i>/devis ' + rows[0].id + ' contacte</i>');
    return C.send(res, 200, { ok: true });
  } catch (e) {
    console.error('[TWD quote]', e.message);
    return C.send(res, 500, { error: 'server_error', message: 'Unable to save your request right now.' });
  }
};
