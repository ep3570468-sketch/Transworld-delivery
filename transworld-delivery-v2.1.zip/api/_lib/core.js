'use strict';
// Fonctions communes : config, statuts, codes, cookies signés, limitation de débit, Telegram, emails, payload public.
const crypto = require('crypto');
const { q, one } = require('./db');

/* ---------------- configuration (variables d'environnement Vercel) ---------------- */
let LOCAL = {};
try { LOCAL = require('./config'); } catch (e) { LOCAL = {}; }
const env = (k, d = '') => (process.env[k] !== undefined && process.env[k] !== '' ? process.env[k] : (LOCAL[k] ? String(LOCAL[k]).trim() : d));
const siteName = () => env('SITE_NAME', 'TRANSWORLD DELIVERY');
const whatsapp = () => env('WHATSAPP', '13434854979');
const timezone = () => env('TIMEZONE', 'Africa/Douala');
function siteUrl() {
  const u = env('SITE_URL') || (process.env.VERCEL_PROJECT_PRODUCTION_URL ? 'https://' + process.env.VERCEL_PROJECT_PRODUCTION_URL : '');
  return u.replace(/\/+$/, '');
}
/** TELEGRAM_ALLOWED="123456789:Prénom,987654321:Autre" -> { 123456789: 'Prénom', ... } */
function team() {
  const out = {};
  env('TELEGRAM_ALLOWED', '7836821898:William').split(',').forEach((p) => {
    const m = p.trim().match(/^(\d{3,15})\s*:\s*(.+)$/);
    if (m) out[m[1]] = m[2].trim();
  });
  return out;
}

/* ---------------- statuts : code => [libellé, progression auto] ---------------- */
const STATUSES = {
  CREATED: ['Shipment Created', 10],
  CONFIRMED: ['Confirmed', 15],
  RECEIVED: ['Package Received', 20],
  PROCESSING: ['Processing', 30],
  PICKED_UP: ['Picked Up', 40],
  IN_TRANSIT: ['In Transit', 60],
  ARRIVED_DESTINATION: ['Arrived at Destination Country', 75],
  CUSTOMS_CLEARANCE: ['Customs Clearance', 85],
  CUSTOMS_CLEARED: ['Customs Cleared', 88],
  LOCAL_FACILITY: ['At Local Facility', 90],
  OUT_FOR_DELIVERY: ['Out for Delivery', 95],
  DELIVERED: ['Delivered', 100],
  DELAYED: ['Delayed', null],
  EXCEPTION: ['Exception', null],
  CANCELLED: ['Cancelled', null],
};
const statusLabel = (s) => (STATUSES[s] ? STATUSES[s][0] : s);
function progressFor(status, current) {
  const p = STATUSES[status] ? STATUSES[status][1] : null;
  return p === null || p === undefined ? current : p;
}

/* ---------------- codes (aléatoire cryptographique) ---------------- */
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function randChars(n) {
  let s = '';
  for (let i = 0; i < n; i++) s += ALPHA[crypto.randomInt(0, ALPHA.length)];
  return s;
}
async function generateTracking() {
  for (let i = 0; i < 20; i++) {
    const no = 'TWD-' + randChars(4) + '-' + randChars(4);
    if (!(await one('SELECT 1 FROM shipments WHERE tracking_number = $1', [no]))) return no;
  }
  throw new Error('Impossible de générer un numéro unique');
}
const generateAccessCode = () => randChars(4) + '-' + randChars(4);
const normCode = (c) => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
function hashCode(c) {
  const salt = crypto.randomBytes(16).toString('hex');
  return 'scrypt$' + salt + '$' + crypto.scryptSync(normCode(c), salt, 32).toString('hex');
}
function verifyCode(c, stored) {
  if (!stored) return false;
  const [t, salt, h] = String(stored).split('$');
  if (t !== 'scrypt' || !salt || !h) return false;
  const a = crypto.scryptSync(normCode(c), salt, 32);
  const b = Buffer.from(h, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/* ---------------- cookie signé : accès accordé après vérification du code ---------------- */
function secret() {
  const s = env('SESSION_SECRET') || env('TELEGRAM_SECRET');
  if (s.length < 16) throw new Error('SESSION_SECRET manquant ou trop court (16 caractères minimum)');
  return s;
}
function sign(obj) {
  const b = Buffer.from(JSON.stringify(obj)).toString('base64url');
  return b + '.' + crypto.createHmac('sha256', secret()).update(b).digest('base64url');
}
function unsign(tok) {
  const i = String(tok || '').lastIndexOf('.');
  if (i < 1) return null;
  const b = tok.slice(0, i);
  const mac = Buffer.from(tok.slice(i + 1));
  const good = Buffer.from(crypto.createHmac('sha256', secret()).update(b).digest('base64url'));
  if (mac.length !== good.length || !crypto.timingSafeEqual(mac, good)) return null;
  try { return JSON.parse(Buffer.from(b, 'base64url').toString()); } catch (e) { return null; }
}
function readCookie(req, name) {
  const m = String(req.headers.cookie || '').split(';').map((x) => x.trim()).find((x) => x.startsWith(name + '='));
  return m ? decodeURIComponent(m.slice(name.length + 1)) : '';
}
/** { 'TWD-XXXX-XXXX': expiration (secondes epoch) } encore valides */
function getGrants(req) {
  const o = unsign(readCookie(req, 'twd_g'));
  const now = Date.now() / 1000;
  const out = {};
  if (o && o.g) for (const k of Object.keys(o.g)) if (o.g[k] > now) out[k] = o.g[k];
  return out;
}
function setGrants(res, grants) {
  const keys = Object.keys(grants).slice(-20);
  const g = {};
  keys.forEach((k) => (g[k] = grants[k]));
  res.setHeader('Set-Cookie', 'twd_g=' + encodeURIComponent(sign({ g })) + '; Path=/api; HttpOnly; Secure; SameSite=Lax; Max-Age=86400');
}

/* ---------------- HTTP ---------------- */
function send(res, code, data) {
  res.statusCode = code;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.end(JSON.stringify(data));
}
function readJson(req) {
  let b = req.body;
  if (typeof b === 'string') { try { b = JSON.parse(b); } catch (e) { return null; } }
  return b && typeof b === 'object' && !Array.isArray(b) ? b : null;
}
function clientIp(req) {
  const ip = req.headers['x-real-ip'] || String(req.headers['x-forwarded-for'] || '').split(',')[0] || (req.socket && req.socket.remoteAddress) || '0.0.0.0';
  return String(ip).trim().slice(0, 45);
}

/* ---------------- limitation de débit (stockée en base) ---------------- */
async function rateHit(bucket) {
  await q('INSERT INTO rate_limits (bucket) VALUES ($1)', [bucket]);
  if (crypto.randomInt(1, 101) === 1) {
    await q("DELETE FROM rate_limits WHERE created_at < now() - interval '1 day'");
    await q("DELETE FROM tg_updates WHERE created_at < now() - interval '3 days'");
  }
}
async function rateCount(bucket, seconds) {
  const r = await one('SELECT count(*)::int AS n FROM rate_limits WHERE bucket = $1 AND created_at > now() - make_interval(secs => $2)', [bucket, seconds]);
  return r.n;
}

/* ---------------- utilitaires ---------------- */
const esc = (s) => String(s === null || s === undefined ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const toISO = (v) => (v ? new Date(v).toISOString() : null);
const num = (v) => (v === null || v === undefined || v === '' ? null : Number(v));
function fmtDate(v) {
  try {
    return new Intl.DateTimeFormat('fr-FR', { timeZone: timezone(), day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).format(new Date(v));
  } catch (e) { return String(v); }
}
function todayStr() {
  try { return new Intl.DateTimeFormat('en-CA', { timeZone: timezone() }).format(new Date()); } catch (e) { return new Date().toISOString().slice(0, 10); }
}
function haversineKm(a, b) {
  const R = 6371, r = (d) => (d * Math.PI) / 180;
  const dLat = r(b[0] - a[0]), dLon = r(b[1] - a[1]);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(r(a[0])) * Math.cos(r(b[0])) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/* ---------------- transport (icône animée) et trajet ---------------- */
const MODES = { air: 'Air Freight', sea: 'Sea Freight', land: 'Land Freight', rail: 'Rail Freight', express: 'Express Delivery', vehicle: 'Vehicle Transport' };
const METHOD_TO_MODE = { 'Air Freight': 'air', 'Sea Freight': 'sea', 'Land Freight': 'land', 'Rail Freight': 'rail', 'Express Delivery': 'express', 'Vehicle Transport': 'vehicle' };
const modeOf = (s) => (s.transport_mode && MODES[s.transport_mode] ? s.transport_mode : METHOD_TO_MODE[s.shipping_method] || 'land');
/** Point situé à la fraction f (0..1) du grand cercle a -> b, tous deux [lat, lng] en degrés. */
function interpolate(a, b, f) {
  const r = (d) => (d * Math.PI) / 180, d = (x) => (x * 180) / Math.PI;
  const [la1, lo1, la2, lo2] = [r(a[0]), r(a[1]), r(b[0]), r(b[1])];
  const dd = 2 * Math.asin(Math.sqrt(Math.sin((la2 - la1) / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin((lo2 - lo1) / 2) ** 2));
  if (!dd) return [a[0], a[1]];
  const A = Math.sin((1 - f) * dd) / Math.sin(dd), B = Math.sin(f * dd) / Math.sin(dd);
  const x = A * Math.cos(la1) * Math.cos(lo1) + B * Math.cos(la2) * Math.cos(lo2);
  const y = A * Math.cos(la1) * Math.sin(lo1) + B * Math.cos(la2) * Math.sin(lo2);
  const z = A * Math.sin(la1) + B * Math.sin(la2);
  return [Math.round(d(Math.atan2(z, Math.sqrt(x * x + y * y))) * 1e6) / 1e6, Math.round(d(Math.atan2(y, x)) * 1e6) / 1e6];
}
/** Supprime définitivement des colis et tout ce qui s'y rattache (événements, positions, messages en cascade). */
async function deleteShipments(ids) {
  if (!ids.length) return 0;
  await q('DELETE FROM notifications WHERE shipment_id = ANY($1::int[])', [ids]);
  await q('UPDATE admin_activity_logs SET shipment_id = NULL WHERE shipment_id = ANY($1::int[])', [ids]);
  const r = await q('DELETE FROM shipments WHERE id = ANY($1::int[]) RETURNING id', [ids]);
  return r.length;
}

async function logActivity(actor, action, shipmentId, desc) {
  await q('INSERT INTO admin_activity_logs (actor, action, shipment_id, description) VALUES ($1,$2,$3,$4)', [actor, action, shipmentId || null, String(desc).slice(0, 500)]);
}

/* ---------------- HTTP sortant, Telegram, géocodage ---------------- */
async function httpReq(url, json, timeout = 5000, headers = {}) {
  try {
    const opt = { signal: AbortSignal.timeout(timeout), headers: { 'User-Agent': 'TransworldDelivery/2.0 (tracking)', ...headers } };
    if (json !== undefined && json !== null) {
      opt.method = 'POST';
      opt.headers['Content-Type'] = 'application/json';
      opt.body = JSON.stringify(json);
    }
    const r = await fetch(url, opt);
    return await r.text();
  } catch (e) {
    console.error('[TWD http] ' + url.split('?')[0] + ' ' + e.message);
    return null;
  }
}
async function tgSend(chat, text, buttons) {
  const tok = env('TELEGRAM_TOKEN');
  if (!tok) return;
  const p = { chat_id: chat, text: String(text).slice(0, 4000), parse_mode: 'HTML', disable_web_page_preview: true };
  if (buttons && buttons.length) p.reply_markup = { inline_keyboard: Array.isArray(buttons[0]) ? buttons : [buttons] };
  await httpReq('https://api.telegram.org/bot' + tok + '/sendMessage', p, 6000);
}
/** Alerte envoyée à toute l'équipe. Ne casse jamais la requête appelante. */
async function tgAlert(html) {
  try { await Promise.allSettled(Object.keys(team()).map((id) => tgSend(Number(id), html))); } catch (e) { console.error('[TWD tgAlert]', e.message); }
}
async function geocode(query) {
  const r = await httpReq('https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent(query), null, 5000);
  try {
    const j = JSON.parse(r);
    if (j && j[0] && j[0].lat && j[0].lon) return [Math.round(parseFloat(j[0].lat) * 1e6) / 1e6, Math.round(parseFloat(j[0].lon) * 1e6) / 1e6];
  } catch (e) { /* ignore */ }
  return null;
}
async function reverseGeocode(lat, lng) {
  const r = await httpReq('https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10&lat=' + lat + '&lon=' + lng, null, 5000);
  try {
    const a = JSON.parse(r).address || {};
    const place = a.city || a.town || a.village || a.municipality || a.county || a.state;
    const out = [place, a.country].filter(Boolean).join(', ');
    return out || null;
  } catch (e) { return null; }
}

/* ---------------- emails (Resend). Sans RESEND_API_KEY + MAIL_FROM : ignorés, journalisés "skipped" ---------------- */
async function notifyEmail(s, type, message) {
  const to = s.customer_email || '';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to)) return;
  const key = env('RESEND_API_KEY'), from = env('MAIL_FROM');
  let status = 'skipped';
  if (key && from) {
    const url = siteUrl() + '/#/track/' + s.tracking_number;
    const body = 'Hello ' + s.customer_name + ',\n\n' + message + '\n\nTracking number: ' + s.tracking_number + '\nTrack here: ' + url + '\n\n' + siteName() + '\nWhatsApp: +' + whatsapp();
    const r = await httpReq('https://api.resend.com/emails', { from: siteName() + ' <' + from + '>', to: [to], subject: siteName() + ' - ' + type, text: body }, 8000, { Authorization: 'Bearer ' + key });
    let ok = false;
    try { ok = !!JSON.parse(r).id; } catch (e) { /* ignore */ }
    status = ok ? 'sent' : 'failed';
  }
  await q('INSERT INTO notifications (shipment_id, type, channel, recipient, message, status) VALUES ($1,$2,$3,$4,$5,$6)', [s.id, type, 'email', to, String(message).slice(0, 500), status]);
}

/* ---------------- données publiques (jamais d'ID, de données client ni de champs internes) ---------------- */
function publicPayload(s, events, trail, messages) {
  const times = [s.location_updated_at, s.updated_at, events[0] && events[0].event_date, messages[0] && messages[0].created_at].filter(Boolean).map((t) => new Date(t).getTime());
  const last = times.length ? new Date(Math.max(...times)).toISOString() : null;
  const lastPos = trail.length ? trail[trail.length - 1] : null;
  const gps = !!(lastPos && lastPos.source === 'gps');
  const join = (a, b) => [a, b].filter(Boolean).join(', ');
  return {
    tracking_number: s.tracking_number,
    status: s.status,
    status_label: statusLabel(s.status),
    progress: Number(s.progress),
    origin: join(s.origin_city, s.origin_country),
    destination: join(s.destination_city, s.destination_country),
    current_location: s.current_location,
    location_source: gps ? 'GPS position shared by our team' : 'Administrator updated location',
    location_gps: gps,
    coords: {
      origin: [num(s.origin_latitude), num(s.origin_longitude)],
      current: [num(s.current_latitude), num(s.current_longitude)],
      destination: [num(s.destination_latitude), num(s.destination_longitude)],
    },
    trail: trail.map((p) => ({ lat: Number(p.latitude), lng: Number(p.longitude), label: p.label, gps: p.source === 'gps', date: toISO(p.created_at) })),
    messages: messages.map((m) => ({ text: m.body, date: toISO(m.created_at) })),
    transport: modeOf(s),
    carrier_name: s.carrier_name || null,
    carrier_ref: s.carrier_ref || null,
    service_level: s.service_level || null,
    contents: s.description || null,
    special_handling: s.special_handling || null,
    insured: !!s.insured,
    shipping_method: s.shipping_method,
    package_type: s.package_type,
    weight: s.weight !== null && s.weight !== undefined ? Number(s.weight) + ' KG' : null,
    quantity: Number(s.quantity),
    dimensions: s.dimensions,
    shipment_date: s.shipment_date,
    estimated_delivery: s.estimated_delivery,
    delivered_at: toISO(s.delivered_at),
    last_update: last,
    events: events.map((e) => ({ status: e.status, label: statusLabel(e.status), location: e.location, description: e.description, date: toISO(e.event_date) })),
  };
}

module.exports = {
  env, siteName, siteUrl, whatsapp, timezone, team,
  STATUSES, statusLabel, progressFor,
  randChars, generateTracking, generateAccessCode, normCode, hashCode, verifyCode,
  getGrants, setGrants, send, readJson, clientIp, rateHit, rateCount,
  esc, toISO, num, fmtDate, todayStr, haversineKm, logActivity,
  MODES, METHOD_TO_MODE, modeOf, interpolate, deleteShipments,
  httpReq, tgSend, tgAlert, geocode, reverseGeocode, notifyEmail, publicPayload,
  q, one,
};
