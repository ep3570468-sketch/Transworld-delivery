'use strict';
// ⚠️ Fichier SECRET : dépôt GitHub PRIVÉ uniquement. Ne le partagez jamais (ni en message, ni en capture).
module.exports = {
  TELEGRAM_TOKEN: 'COLLEZ_ICI_LE_NOUVEAU_TOKEN_DE_BOTFATHER',
  TELEGRAM_SECRET: 'F_QHUCL95WOEO2t8VZT5xdm2cT6mvAFqLLWLnOTTMzeZVIMb',
  SESSION_SECRET: 'AsAskQYbMhBFXXG3XNbHW2Fd_PWtLW8ZwXozRYbWpGJksYHs_BZAFQ',
  DATABASE_URL: '',   // optionnel : collez ici l'adresse postgresql://... de Neon ou Supabase si Vercel ne la fournit pas
  SITE_URL: 'https://transworld-delivery-ten.vercel.app',
  TELEGRAM_ALLOWED: '7836821898:William',
};
