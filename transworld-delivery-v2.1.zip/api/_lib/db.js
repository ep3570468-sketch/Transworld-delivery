'use strict';
// Connexion Postgres (Neon via Vercel Marketplace, Supabase, etc.)
const { Pool } = require('pg');

let pool = null;
function getPool() {
  if (!pool) {
    let cfg = {}; try { cfg = require('./config'); } catch (e) {}
    const url = process.env.DATABASE_URL || process.env.POSTGRES_URL || cfg.DATABASE_URL;
    if (!url) throw new Error('DATABASE_URL manquant (variable d\'environnement Vercel)');
    pool = new Pool({ connectionString: url, max: 3, idleTimeoutMillis: 10000, connectionTimeoutMillis: 8000 });
    pool.on('error', (e) => console.error('[TWD db] pool error', e.message));
  }
  return pool;
}

/** Requête paramétrée ($1, $2...) -> tableau de lignes. */
async function q(text, params = []) {
  const r = await getPool().query(text, params);
  return r.rows;
}
async function one(text, params = []) {
  const rows = await q(text, params);
  return rows[0] || null;
}

module.exports = { q, one };
