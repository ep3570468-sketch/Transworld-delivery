'use strict';
// Test de bout en bout de l'API (track, quote, bot Telegram) contre une base Postgres DE TEST.
//   TEST_DATABASE_URL=postgres://user:pass@localhost:5432/twd_test npm test
// ATTENTION : vide les tables ! N'utilisez jamais la base de production.
const path = require('path');
const fs = require('fs');

const DB = process.env.TEST_DATABASE_URL;
if (!DB) { console.error('TEST_DATABASE_URL manquant (base de TEST uniquement : elle sera vidée).'); process.exit(2); }
Object.assign(process.env, {
  DATABASE_URL: DB, TELEGRAM_TOKEN: '123:TESTTOKEN', TELEGRAM_SECRET: 's'.repeat(32), TELEGRAM_ALLOWED: '111:Alice',
  SESSION_SECRET: 'x'.repeat(40), SITE_URL: 'https://example.test', TIMEZONE: 'Africa/Douala', RESEND_API_KEY: '', MAIL_FROM: '',
});

/* ---- faux réseau : Telegram + Nominatim ---- */
const sent = [];
global.fetch = async (url, opt = {}) => {
  const u = String(url);
  const ok = (o) => ({ text: async () => JSON.stringify(o) });
  if (u.includes('api.telegram.org')) { if (u.includes('sendMessage')) sent.push(JSON.parse(opt.body)); return ok({ ok: true }); }
  if (u.includes('nominatim') && u.includes('/reverse')) return ok({ address: { city: 'Dubai', country: 'UAE' } });
  if (u.includes('nominatim')) {
    const qs = decodeURIComponent(u.split('q=')[1] || '');
    const t = { Shanghai: ['31.2304', '121.4737'], Douala: ['4.0511', '9.7679'], Dubai: ['25.2048', '55.2708'] };
    const k = Object.keys(t).find((x) => qs.includes(x));
    return ok(k ? [{ lat: t[k][0], lon: t[k][1] }] : []);
  }
  throw new Error('réseau inattendu : ' + u);
};

const C = require('../api/_lib/core');
const track = require('../api/track');
const quote = require('../api/quote');
const tg = require('../api/telegram');

let pass = 0, fail = 0;
const ok = (name, cond, extra) => { if (cond) { pass++; console.log('[PASS] ' + name); } else { fail++; console.log('[FAIL] ' + name + (extra ? ' -> ' + JSON.stringify(extra) : '')); } };

function call(handler, { method = 'POST', headers = {}, body } = {}) {
  return new Promise((resolve, reject) => {
    const res = { statusCode: 200, headers: {}, setHeader(k, v) { this.headers[k.toLowerCase()] = v; }, end(b) { let j = null; try { j = JSON.parse(b); } catch (e) { /* texte */ } resolve({ status: this.statusCode, headers: this.headers, json: j, text: b }); } };
    Promise.resolve(handler({ method, headers: { 'x-real-ip': '10.0.0.1', ...headers }, body, socket: {} }, res)).catch(reject);
  });
}
const hook = (b, secret) => call(tg, { headers: { 'x-telegram-bot-api-secret-token': secret === undefined ? process.env.TELEGRAM_SECRET : secret }, body: b });
let uid = 1000;
const say = (text, from = 111) => hook({ update_id: ++uid, message: { text, from: { id: from }, chat: { id: from, type: 'private' } } });
const press = (data, from = 111) => hook({ update_id: ++uid, callback_query: { id: 'cb' + uid, data, from: { id: from }, message: { chat: { id: from, type: 'private' } } } });
const lastKb = () => JSON.stringify((sent.length ? sent[sent.length - 1].reply_markup : null) || {});
const lastText = () => (sent.length ? sent[sent.length - 1].text : '');
const cookieOf = (r) => (r.headers['set-cookie'] || '').split(';')[0];

(async () => {
  await C.q('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await C.q(fs.readFileSync(path.join(__dirname, '..', 'sql', 'schema.sql'), 'utf8'));

  /* ---- API publique : garde-fous ---- */
  ok('track GET refusé (405)', (await call(track, { method: 'GET' })).status === 405);
  ok('track format invalide => 404', (await call(track, { body: { tracking: 'abc' } })).status === 404);
  ok('track numéro inconnu => 404', (await call(track, { body: { tracking: 'TWD-ZZZZ-ZZZZ' } })).status === 404);

  /* ---- bot : sécurité ---- */
  ok('webhook sans secret => 403', (await hook({ update_id: 1 }, 'mauvais')).status === 403);
  await say('/aide', 999);
  ok('inconnu => accès refusé + son ID', lastText().includes('Accès refusé') && lastText().includes('999'));
  const nBefore = await C.one('SELECT count(*)::int AS n FROM shipments');
  await say('/nouveau Pirate | Paris, France | Douala, Cameroon | air', 999);
  ok('inconnu ne peut pas créer de colis', (await C.one('SELECT count(*)::int AS n FROM shipments')).n === nBefore.n);
  await say('/aide');
  ok('équipe : /aide', lastText().includes('/nouveau') && lastText().includes('/message'));

  /* ---- création d'un colis par Telegram ---- */
  await say('/nouveau Jean Dupont | Shanghai, China | Douala, Cameroon | air | 12 | +237600000000 | permanent');
  const created = lastText();
  const no = (created.match(/TWD-[A-Z0-9]{4}-[A-Z0-9]{4}/) || [])[0];
  const code = (created.match(/Code : <code>([A-Z0-9]{4}-[A-Z0-9]{4})<\/code>/) || [])[1];
  ok('/nouveau génère numéro + code', !!no && !!code, created);
  ok('bouton WhatsApp avec le numéro du client', JSON.stringify(sent[sent.length - 1].reply_markup || {}).includes('wa.me/237600000000'));
  const row = await C.one('SELECT * FROM shipments WHERE tracking_number = $1', [no]);
  ok('code stocké haché (jamais en clair)', row.access_token_hash.startsWith('scrypt$') && !row.access_token_hash.includes(code.replace('-', '')));
  ok('villes géolocalisées', row.origin_latitude > 31 && row.destination_latitude > 4);
  ok('1ère position (origine) dans l\'historique', (await C.one('SELECT count(*)::int AS n FROM positions WHERE shipment_id=$1', [row.id])).n === 1);

  /* ---- doublon Telegram (même update_id) ---- */
  const dup = { update_id: 777777, message: { text: '/nouveau Doublon | Paris, France | Douala, Cameroon | air', from: { id: 111 }, chat: { id: 111, type: 'private' } } };
  await hook(dup); await hook(dup);
  ok('même update_id traité une seule fois', (await C.one("SELECT count(*)::int AS n FROM shipments WHERE customer_name='Doublon'")).n === 1);

  /* ---- côté client : code, cookie, données publiques ---- */
  let r = await call(track, { body: { tracking: no } });
  ok('sans code => 401 need_code', r.status === 401 && r.json.need_code);
  r = await call(track, { body: { tracking: no, code: 'AAAA-BBBB' } });
  ok('mauvais code => 401', r.status === 401 && r.json.error === 'invalid_code');
  r = await call(track, { body: { tracking: no, code: code.toLowerCase().replace('-', ' ') } });
  ok('bon code (casse/format libres) => 200', r.status === 200 && r.json.shipment.tracking_number === no, r.json);
  const ck = cookieOf(r);
  ok('cookie d\'accès signé HttpOnly', ck.startsWith('twd_g=') && /HttpOnly/.test(r.headers['set-cookie']));
  const raw = JSON.stringify(r.json);
  ok('aucune donnée privée exposée', !/Jean|Dupont|237600000000|customer_|access_token|"id"/.test(raw), raw.slice(0, 200));
  r = await call(track, { headers: { cookie: ck }, body: { tracking: no } });
  ok('cookie valide => suivi sans re-saisir le code', r.status === 200);
  r = await call(track, { headers: { cookie: ck.slice(0, -3) + 'xyz' }, body: { tracking: no } });
  ok('cookie falsifié refusé', r.status === 401);

  /* ---- position, messages, GPS ---- */
  await say('/position ' + no + ' Dubai Logistics Hub');
  ok('/position avec lieu', lastText().includes('Position mise à jour'));
  await say('/message ' + no + 'Votre colis est arrivé à Dubaï.\nDépart demain.');
  ok('/message sans espace => format refusé', lastText().includes('Format'));
  await say('/message ' + no + ' Votre colis est arrivé à Dubaï.\nDépart demain.');
  ok('/message publié', lastText().includes('Message publié'));
  r = await call(track, { headers: { cookie: ck }, body: { tracking: no } });
  let d = r.json.shipment;
  ok('le client voit le message', d.messages.length === 1 && d.messages[0].text.includes('Dépar'), d.messages);
  ok('le client voit la nouvelle position sur la carte', d.trail.length === 2 && d.current_location === 'Dubai Logistics Hub' && Math.round(d.coords.current[0]) === 25, d.trail);
  ok('source manuelle annoncée honnêtement', d.location_gps === false && d.location_source === 'Administrator updated location');

  await say('/position ' + no);
  ok('/position seul => attend le GPS', lastText().includes('sélectionné'));
  const pin = (lat, lng, edited) => hook({ update_id: ++uid, [edited ? 'edited_message' : 'message']: { from: { id: 111 }, chat: { id: 111, type: 'private' }, location: { latitude: lat, longitude: lng } } });
  await pin(25.30, 55.35);
  r = await call(track, { headers: { cookie: ck }, body: { tracking: no } });
  d = r.json.shipment;
  ok('position GPS ajoutée au parcours', d.trail.length === 3 && d.trail[2].gps === true && d.location_gps === true && d.current_location === 'Dubai, UAE', d.trail);
  await pin(25.31, 55.36, true);
  ok('position en direct < 60 s ignorée', (await C.one('SELECT count(*)::int AS n FROM positions WHERE shipment_id=$1', [row.id])).n === 3);
  await C.q("UPDATE positions SET created_at = now() - interval '5 minutes' WHERE shipment_id=$1 AND source='gps'", [row.id]);
  await pin(25.32, 55.37, true);
  ok('position en direct après 1 min enregistrée', (await C.one('SELECT count(*)::int AS n FROM positions WHERE shipment_id=$1', [row.id])).n === 4);
  await pin(1, 1, false); // 2e épingle sans changement de colis : ok
  await C.q('DELETE FROM bot_state');
  const before = sent.length;
  await pin(10, 10, false);
  ok('GPS sans colis sélectionné => explication', sent.length === before + 1 && lastText().includes('/position'));

  /* ---- statut, eta, modifier ---- */
  await say('/statut ' + no + ' transit Dubai');
  r = await call(track, { headers: { cookie: ck }, body: { tracking: no } });
  d = r.json.shipment;
  ok('/statut => statut + progression + événement', d.status === 'IN_TRANSIT' && d.progress === 60 && d.events[0].label === 'In Transit', d.status);
  await say('/eta ' + no + ' 2026-11-20');
  await say('/modifier ' + no + ' poids 15,5');
  r = await call(track, { headers: { cookie: ck }, body: { tracking: no } });
  ok('/eta et /modifier visibles', r.json.shipment.estimated_delivery === '2026-11-20' && r.json.shipment.weight === '15.5 KG', r.json.shipment.weight);
  await say('/modifier ' + no + ' email pas-un-email');
  ok('/modifier valide les entrées', lastText().includes('Email invalide'));
  await say('/statut ' + no + ' livre');
  r = await call(track, { headers: { cookie: ck }, body: { tracking: no } });
  ok('livré => 100 % + date de livraison', r.json.shipment.progress === 100 && !!r.json.shipment.delivered_at);

  /* ---- code à usage unique ---- */
  await say('/code ' + no + ' unique 2');
  const code1 = (lastText().match(/<code>([A-Z0-9]{4}-[A-Z0-9]{4})<\/code>/g) || []).map((x) => x.replace(/<[^>]+>/g, ''))[0];
  ok('/code unique génère un nouveau code', !!code1, lastText());
  r = await call(track, { headers: { 'x-real-ip': '10.0.0.7' }, body: { tracking: no, code: code } });
  ok('ancien code invalidé', r.status === 401);
  r = await call(track, { headers: { 'x-real-ip': '10.0.0.8' }, body: { tracking: no, code: code1 } });
  ok('code unique accepté 1 fois', r.status === 200);
  r = await call(track, { headers: { 'x-real-ip': '10.0.0.9' }, body: { tracking: no, code: code1 } });
  ok('code unique refusé la 2e fois', r.status === 403 && r.json.error === 'code_used');
  ok('alerte équipe à l\'usage du code unique', sent.some((m) => (m.text || '').includes('One-time code used')));

  /* ---- anti brute-force ---- */
  await say('/code ' + no + ' permanent');
  let last;
  for (let i = 0; i < 6; i++) last = await call(track, { headers: { 'x-real-ip': '10.9.9.9' }, body: { tracking: no, code: 'ZZZZ-' + i + 'AAA' } });
  ok('6e mauvais code => 429', last.status === 429);

  /* ---- suivi coupé / archivé ---- */
  await say('/off ' + no);
  ok('/off => suivi public coupé (404)', (await call(track, { headers: { cookie: ck, 'x-real-ip': '10.1.1.1' }, body: { tracking: no } })).status === 404);
  await say('/on ' + no);
  await say('/archiver ' + no);
  ok('/archiver => introuvable côté public', (await call(track, { headers: { cookie: ck, 'x-real-ip': '10.1.1.2' }, body: { tracking: no } })).status === 404);
  await say('/desarchiver ' + no);
  ok('/desarchiver => de nouveau visible', (await call(track, { headers: { cookie: ck, 'x-real-ip': '10.1.1.3' }, body: { tracking: no } })).status === 200);

  /* ---- devis / contact ---- */
  ok('devis sans nom => 422', (await call(quote, { body: { name: '' } })).status === 422);
  ok('devis honeypot ignoré', (await call(quote, { body: { name: 'bot', phone: '1', website: 'x' } })).status === 200 && (await C.one('SELECT count(*)::int AS n FROM quotes')).n === 0);
  r = await call(quote, { body: { kind: 'quote', name: '<b>Marie</b>', phone: '+33600000000', origin: 'Paris', destination: 'Douala', cargo: '3 cartons', mode: 'Air Freight' } });
  ok('devis enregistré', r.status === 200 && (await C.one('SELECT name FROM quotes')).name === 'Marie');
  ok('équipe alertée sur Telegram', lastText().includes('Nouvelle demande') && lastText().includes('Marie'));
  await say('/devis');
  ok('/devis liste', lastText().includes('Marie'));
  await say('/devis 1 contacte');
  ok('/devis ID contacte', (await C.one('SELECT status FROM quotes WHERE id=1')).status === 'contacted');

  /* ---- reste des commandes d'équipe ---- */
  for (const c of ['/info ' + no, '/historique ' + no, '/messages ' + no, '/liste', '/stats', '/journal', '/commande-inconnue']) {
    const n0 = sent.length; await say(c);
    ok('commande ' + c.split(' ')[0] + ' répond', sent.length === n0 + 1 && !lastText().includes('Erreur serveur'), lastText().slice(0, 120));
  }


  /* ---- v2.1 : avancement, icône de transport, détails, boutons, suppression ---- */
  await C.q("DELETE FROM rate_limits WHERE bucket LIKE 'tg:%'"); // la limite de 40 commandes/min ne doit pas fausser la suite
  const getD = async () => (await call(track, { headers: { cookie: ck, 'x-real-ip': '10.2.2.' + (++uid % 200) }, body: { tracking: no } })).json.shipment;
  await say('/progres ' + no + ' 50');
  let dd = await getD();
  ok('/progres 50 : barre à 50 % + nouvelle position sur la route', dd.progress === 50 && /50%/.test(dd.current_location) && dd.coords.current[0] > 4 && dd.coords.current[0] < 32, dd.coords);
  await say('/progres ' + no + ' +10');
  ok('/progres +10', (await getD()).progress === 60);
  await say('/progres ' + no + ' 100');
  dd = await getD();
  ok('/progres 100 : position = destination', Math.abs(dd.coords.current[0] - 4.0511) < 0.05 && Math.abs(dd.coords.current[1] - 9.7679) < 0.05, dd.coords.current);
  await say('/transport ' + no + ' mer');
  ok('/transport mer : le client reçoit transport=sea', (await getD()).transport === 'sea');
  await say('/transport ' + no + ' avion');
  ok('/transport inconnu refusé', (await getD()).transport === 'sea' && lastText().includes('Format'));
  await say('/details ' + no + ' transporteur=MSC Aurora | reference=VOY 245E | service=Express | destinataire=Marie Kamga | teldest=+237611111111 | adresse=Rue 1, Douala | assurance=oui | paiement=paye | fragile=Fragile | contenu=Vêtements');
  dd = await getD();
  ok('/details : infos publiques visibles côté client', dd.carrier_name === 'MSC Aurora' && dd.carrier_ref === 'VOY 245E' && dd.service_level === 'Express' && dd.contents === 'Vêtements' && dd.special_handling === 'Fragile' && dd.insured === true, dd);
  ok('/details : destinataire et paiement restent privés', !/Marie|237611111111|Rue 1|paid/.test(JSON.stringify(dd)));
  await say('/details ' + no + ' foo=bar');
  ok('/details champ inconnu signalé', lastText().includes('Champ inconnu'));
  await say('/colis ' + no);
  ok('/colis : panneau à boutons', lastKb().includes('|msg') && lastKb().includes('|pg|+10') && lastKb().includes('|del'));
  await press('p|' + row.id + '|msg');
  await say('Votre colis a quitté Dubaï.');
  r = await getD();
  ok('bouton Message + texte suivant => message visible du client', r.messages.some((m) => m.text.includes('quitté Dubaï')));
  await press('p|' + row.id + '|pg|-10');
  ok('bouton -10 % appliqué', (await getD()).progress === 90);

  /* ---- suppression d'anciens codes ---- */
  await C.q("DELETE FROM rate_limits WHERE bucket LIKE 'tg:%'");
  await say('/nouveau A Supprimer | Shanghai, China | Douala, Cameroon | mer | 5 | +237622222222 | permanent');
  const no2 = (lastText().match(/TWD-[A-Z0-9]{4}-[A-Z0-9]{4}/) || [])[0];
  const row2 = await C.one('SELECT * FROM shipments WHERE tracking_number = $1', [no2]);
  await say('/message ' + no2 + ' test');
  await say('/supprimer ' + no2);
  ok('/supprimer demande confirmation', lastText().includes('Supprimer définitivement') && !!(await C.one('SELECT 1 FROM shipments WHERE id=$1', [row2.id])));
  await press('p|' + row2.id + '|dely', 222); // membre non autorisé
  ok('bouton Supprimer refusé à un inconnu', !!(await C.one('SELECT 1 FROM shipments WHERE id=$1', [row2.id])));
  await press('p|' + row2.id + '|dely');
  ok('confirmation : colis + historique + messages supprimés', !(await C.one('SELECT 1 FROM shipments WHERE id=$1', [row2.id])) && (await C.one('SELECT count(*)::int AS n FROM messages WHERE shipment_id=$1', [row2.id])).n === 0 && (await C.one('SELECT count(*)::int AS n FROM positions WHERE shipment_id=$1', [row2.id])).n === 0);
  ok('suppression journalisée', !!(await C.one("SELECT 1 FROM admin_activity_logs WHERE action='shipment_delete' AND description LIKE $1", ['%' + no2 + '%'])));
  ok('code supprimé : introuvable côté public', (await call(track, { headers: { 'x-real-ip': '10.3.3.3' }, body: { tracking: no2 } })).status === 404);

  await say('/nouveau Vieux Un | Shanghai, China | Douala, Cameroon | mer | 5 | +237633333333 | permanent');
  const no3 = (lastText().match(/TWD-[A-Z0-9]{4}-[A-Z0-9]{4}/) || [])[0];
  await say('/nouveau Vieux Deux | Shanghai, China | Douala, Cameroon | air | 5 | +237644444444 | permanent');
  const no4 = (lastText().match(/TWD-[A-Z0-9]{4}-[A-Z0-9]{4}/) || [])[0];
  await say('/archiver ' + no3);
  await say('/statut ' + no4 + ' livre');
  await C.q("UPDATE shipments SET updated_at = now() - interval '90 days' WHERE tracking_number = $1", [no4]);
  await say('/nettoyer 30');
  ok('/nettoyer liste les archivés et les vieux livrés, pas les actifs', lastText().includes(no3) && lastText().includes(no4) && !lastText().includes(no));
  const confirmData = (sent[sent.length - 1].reply_markup.inline_keyboard[0][0] || {}).callback_data;
  await press(confirmData);
  ok('confirmation : anciens codes supprimés, colis actif conservé', !(await C.one('SELECT 1 FROM shipments WHERE tracking_number=$1', [no3])) && !(await C.one('SELECT 1 FROM shipments WHERE tracking_number=$1', [no4])) && !!(await C.one('SELECT 1 FROM shipments WHERE tracking_number=$1', [no])));
  await say('/nettoyer 30');
  ok('/nettoyer : plus rien à supprimer', lastText().includes('Rien à nettoyer') || lastText().includes('ancien'), lastText().slice(0, 120));

  console.log('\n' + pass + ' réussis, ' + fail + ' échoués.');
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(1); });
