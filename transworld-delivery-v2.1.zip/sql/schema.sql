-- TRANSWORLD DELIVERY - schéma PostgreSQL (Neon / Supabase / tout Postgres 13+)
-- Exécution : collez ce fichier dans l'éditeur SQL de Neon, ou lancez `npm run migrate`. Peut être rejoué sans risque.

CREATE TABLE IF NOT EXISTS shipments (
  id SERIAL PRIMARY KEY,
  tracking_number VARCHAR(20) NOT NULL UNIQUE,
  access_mode VARCHAR(12) NOT NULL DEFAULT 'none' CHECK (access_mode IN ('none','permanent','temporary','one_time')),
  access_token_hash TEXT NULL,
  access_expires_at TIMESTAMPTZ NULL,
  access_used_at TIMESTAMPTZ NULL,
  customer_name VARCHAR(150) NOT NULL,
  customer_email VARCHAR(190) NULL,
  customer_phone VARCHAR(40) NULL,
  origin_country VARCHAR(80) NOT NULL,
  origin_city VARCHAR(80) NOT NULL,
  origin_latitude DOUBLE PRECISION NULL,
  origin_longitude DOUBLE PRECISION NULL,
  destination_country VARCHAR(80) NOT NULL,
  destination_city VARCHAR(80) NOT NULL,
  destination_latitude DOUBLE PRECISION NULL,
  destination_longitude DOUBLE PRECISION NULL,
  current_location VARCHAR(160) NULL,
  current_latitude DOUBLE PRECISION NULL,
  current_longitude DOUBLE PRECISION NULL,
  location_updated_at TIMESTAMPTZ NULL,
  shipping_method VARCHAR(40) NOT NULL DEFAULT 'Air Freight',
  package_type VARCHAR(60) NULL,
  weight DOUBLE PRECISION NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  dimensions VARCHAR(80) NULL,
  description TEXT NULL,
  declared_value DOUBLE PRECISION NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'CREATED',
  progress SMALLINT NOT NULL DEFAULT 10,
  shipment_date TEXT NULL,        -- AAAA-MM-JJ
  estimated_delivery TEXT NULL,   -- AAAA-MM-JJ
  delivered_at TIMESTAMPTZ NULL,
  tracking_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  archived BOOLEAN NOT NULL DEFAULT FALSE,
  admin_note TEXT NULL,
  created_by VARCHAR(80) NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_shipments_status ON shipments (status);
CREATE INDEX IF NOT EXISTS idx_shipments_created ON shipments (created_at DESC);

CREATE TABLE IF NOT EXISTS tracking_events (
  id SERIAL PRIMARY KEY,
  shipment_id INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
  status VARCHAR(30) NOT NULL,
  location VARCHAR(160) NULL,
  latitude DOUBLE PRECISION NULL,
  longitude DOUBLE PRECISION NULL,
  description VARCHAR(500) NULL,
  event_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by VARCHAR(80) NULL
);
CREATE INDEX IF NOT EXISTS idx_events_ship ON tracking_events (shipment_id, event_date DESC);

-- Historique des positions : sert à tracer le parcours sur la carte
CREATE TABLE IF NOT EXISTS positions (
  id SERIAL PRIMARY KEY,
  shipment_id INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
  label VARCHAR(160) NULL,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  source VARCHAR(10) NOT NULL DEFAULT 'manual' CHECK (source IN ('manual','gps','status')),
  created_by VARCHAR(80) NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_positions_ship ON positions (shipment_id, created_at DESC);

-- Messages de l'équipe visibles par le client sur la page de suivi
CREATE TABLE IF NOT EXISTS messages (
  id SERIAL PRIMARY KEY,
  shipment_id INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
  body VARCHAR(1000) NOT NULL,
  author VARCHAR(80) NULL,
  visible BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_messages_ship ON messages (shipment_id, created_at DESC);

CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  shipment_id INTEGER NULL,
  type VARCHAR(60) NOT NULL,
  channel VARCHAR(20) NOT NULL DEFAULT 'email',
  recipient VARCHAR(190) NOT NULL,
  message VARCHAR(500) NOT NULL,
  status VARCHAR(10) NOT NULL,  -- sent | failed | skipped
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS quotes (
  id SERIAL PRIMARY KEY,
  kind VARCHAR(10) NOT NULL DEFAULT 'quote' CHECK (kind IN ('quote','contact')),
  name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NULL,
  phone VARCHAR(40) NULL,
  origin VARCHAR(120) NULL,
  destination VARCHAR(120) NULL,
  cargo VARCHAR(200) NULL,
  weight VARCHAR(60) NULL,
  shipping_method VARCHAR(40) NULL,
  message TEXT NULL,
  status VARCHAR(10) NOT NULL DEFAULT 'new' CHECK (status IN ('new','contacted','closed')),
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_quotes_status ON quotes (status, created_at DESC);

CREATE TABLE IF NOT EXISTS admin_activity_logs (
  id SERIAL PRIMARY KEY,
  actor VARCHAR(80) NULL,
  action VARCHAR(60) NOT NULL,
  shipment_id INTEGER NULL,
  description VARCHAR(500) NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_logs_created ON admin_activity_logs (created_at DESC);

CREATE TABLE IF NOT EXISTS rate_limits (
  id BIGSERIAL PRIMARY KEY,
  bucket VARCHAR(140) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_rate_bucket ON rate_limits (bucket, created_at);

-- Colis "sélectionné" par un membre de l'équipe (pour recevoir sa position GPS Telegram)
CREATE TABLE IF NOT EXISTS bot_state (
  chat_id BIGINT PRIMARY KEY,
  shipment_id INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL
);

-- Anti-doublon : Telegram peut renvoyer le même message
CREATE TABLE IF NOT EXISTS tg_updates (
  update_id BIGINT PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- v2.1 : informations détaillées du colis + type de transport (icône animée sur la carte). Rejouable sans risque.
ALTER TABLE shipments ADD COLUMN IF NOT EXISTS transport_mode VARCHAR(10) NULL;         -- air | sea | land | rail | express | vehicle
ALTER TABLE shipments ADD COLUMN IF NOT EXISTS carrier_name VARCHAR(120) NULL;          -- compagnie / navire / transporteur
ALTER TABLE shipments ADD COLUMN IF NOT EXISTS carrier_ref VARCHAR(80) NULL;            -- n° de vol, voyage, conteneur, plaque...
ALTER TABLE shipments ADD COLUMN IF NOT EXISTS service_level VARCHAR(60) NULL;          -- Express, Standard, Économique...
ALTER TABLE shipments ADD COLUMN IF NOT EXISTS receiver_name VARCHAR(150) NULL;         -- privé (bot uniquement)
ALTER TABLE shipments ADD COLUMN IF NOT EXISTS receiver_phone VARCHAR(40) NULL;         -- privé (bot uniquement)
ALTER TABLE shipments ADD COLUMN IF NOT EXISTS receiver_address VARCHAR(250) NULL;      -- privé (bot uniquement)
ALTER TABLE shipments ADD COLUMN IF NOT EXISTS insured BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE shipments ADD COLUMN IF NOT EXISTS payment_status VARCHAR(20) NULL;         -- paid | pending | partial
ALTER TABLE shipments ADD COLUMN IF NOT EXISTS special_handling VARCHAR(200) NULL;      -- fragile, chaîne du froid...

-- v2.1 : saisie guidée depuis les boutons du bot (le bot attend votre prochain message : texte client, lieu, date, détails)
ALTER TABLE bot_state ADD COLUMN IF NOT EXISTS awaiting VARCHAR(10) NULL;
ALTER TABLE bot_state ADD COLUMN IF NOT EXISTS awaiting_at TIMESTAMPTZ NULL;
