# TRANSWORLD DELIVERY - version Vercel (v2.1)

Site vitrine + suivi de colis **sans PHP ni MySQL** : fichiers statiques + fonctions Node (`api/`) + base **Postgres** (Neon). Le **bot Telegram remplace le panneau admin**.

```
index.html                      SITE COMPLET EN 1 FICHIER (CSS, JS, logo, vidéo et images intégrés)
404.html, 500.html              pages d'erreur (autonomes)
api/track.js                    POST {tracking, code} -> statut, carte, messages
api/quote.js                    POST devis / contact -> base + alerte Telegram
api/telegram.js                 webhook du bot (équipe uniquement)
api/_lib/                       code commun (non exposé comme route)
sql/schema.sql                  tables Postgres (rejouable)
scripts/migrate.js              crée les tables        ->  npm run migrate
scripts/set-webhook.js          branche le bot + menu  ->  npm run webhook (ou /api/setup)
tests/run.js                    tests de bout en bout (base de TEST uniquement)
.env.example                    liste des variables d'environnement
```

## Nouveautés v2.1
- **Numéro WhatsApp / téléphone : +1 343 485 4979** (`wa.me/13434854979`) partout : site, bot, emails, SEO.
- **Page de suivi : tous les boutons fonctionnent** : Actualiser, Copier le numéro, Partager (lien direct), Imprimer / PDF, Mises à jour en direct (pause/reprise), Suivre un autre colis, Suivre le colis sur la carte, Trajet complet, **Rejouer le voyage**, Plein écran (Échap pour quitter), Afficher tous les événements, Marquer les messages comme lus.
- **Icône de transport animée** (✈️ avion, 🚢 bateau, 🚚 camion, 🚆 train, ⚡ express, 🚗 véhicule) : sur la barre de progression **et** sur la carte. Elle avance de l'origine à la destination chaque fois que l'équipe met à jour le colis depuis le bot, et glisse en douceur chez le client sans recharger la page.
- **Informations détaillées, modifiables depuis le bot** : transporteur / navire, n° de vol-voyage-conteneur, service, contenu, manutention spéciale, assurance, poids, dimensions… (public) ; destinataire, téléphone et adresse du destinataire, paiement (privés, jamais envoyés au site).
- **Bot à boutons** : `/liste` ou `/colis TWD-XXXX-XXXX` ouvre un panneau (position, message, ±10 %, statut, transport, détails, date estimée, nouveau code, couper le suivi, archiver, supprimer).
- **Suppression des anciens codes** : `/supprimer` (un code) et `/nettoyer` (tous les codes archivés, coupés ou livrés/annulés depuis plus de N jours), toujours avec confirmation, journalisée.

### Si votre site tourne déjà (mise à jour)
1. Remplacez les fichiers de votre dépôt par ceux de ce dossier (gardez votre `api/_lib/config.js` / vos variables Vercel), poussez sur GitHub : Vercel redéploie.
2. Dans Vercel > Settings > Environment Variables : si la variable **`WHATSAPP`** existe, mettez-la à **`13434854979`** (sinon rien à faire), puis redéployez.
3. **Ouvrez UNE fois** `https://VOTRE-SITE/api/setup?key=VOTRE_TELEGRAM_SECRET` : cela ajoute les nouvelles colonnes en base (sans rien effacer), réactive le webhook **avec les boutons** (`callback_query`) et met à jour le menu du bot. Sans cette étape, les boutons du bot ne répondront pas.
4. Tapez `/aide` puis `/liste` au bot.

## Mise en ligne (30 min)

1. **Révoquez l'ancien token Telegram** (il était écrit dans l'ancien `config.php`) : @BotFather > `/revoke` > choisissez le bot > copiez le **nouveau token**.
2. **GitHub** : créez un dépôt privé et poussez ce dossier. (`.env` est ignoré : ne commitez jamais de secrets.)
3. **Vercel** > *Add New Project* > importez le dépôt. Preset « Other », aucune commande de build.
4. **Base de données** : Vercel > *Storage* > *Neon (Postgres)* > connectez-la au projet : `DATABASE_URL` est ajoutée automatiquement.
5. **Variables** (Vercel > Settings > Environment Variables), voir `.env.example` :
   `TELEGRAM_TOKEN`, `TELEGRAM_SECRET` (30+ caractères aléatoires), `TELEGRAM_ALLOWED`, `SESSION_SECRET` (32+ caractères aléatoires), `SITE_URL`, `TIMEZONE`.
   `TELEGRAM_ALLOWED` = `ID:Nom,ID:Nom`. Pour connaître votre ID : écrivez au bot, il répond « Accès refusé » avec votre ID ; ajoutez-le puis redéployez.
6. **Redéployez**, puis ouvrez **une seule fois** `https://VOTRE-SITE/api/setup?key=VOTRE_TELEGRAM_SECRET` : crée les tables, branche le bot (boutons compris), installe le menu et vous envoie un message de test. (Alternative en ligne de commande : `DATABASE_URL="..." npm run migrate` puis `TELEGRAM_TOKEN=... TELEGRAM_SECRET=... SITE_URL=https://votre-site npm run webhook`.)
7. Vérifiez que `WHATSAPP=13434854979` est bien dans les variables (voir `.env.example`).
8. Écrivez `/aide` au bot. Créez un colis avec `/nouveau`, ouvrez le lien reçu, testez avec le code.
9. Domaine : Vercel > Domains, puis mettez `SITE_URL` à jour et relancez `npm run webhook`.

## Utiliser le bot (remplace l'admin)

**Le plus simple : les boutons.** `/liste` (10 derniers colis) ou `/colis TWD-XXXX-XXXX` ouvre le panneau du colis. Les boutons « Position », « Message client », « Date estimée » et « Détails » vous demandent ensuite d'écrire la valeur dans votre prochain message (`/annuler` pour abandonner).

| Besoin | Commande |
|---|---|
| Créer un colis + code | `/nouveau Jean Dupont \| Shanghai, China \| Douala, Cameroon \| air \| 12 \| +237600000000 \| permanent` |
| Envoyer au client | bouton « Envoyer au client sur WhatsApp » (message prêt avec lien direct) |
| Ajouter / modifier les infos | `/details TWD-XXXX-XXXX transporteur=MSC Aurora \| reference=VOY 245E \| service=Express \| destinataire=Marie \| teldest=+237600000000 \| adresse=Rue 1, Douala \| assurance=oui \| paiement=paye \| fragile=Fragile \| poids=15 \| dimensions=40x30x20 \| contenu=Vêtements` |
| Un seul champ (`-` = effacer) | `/modifier TWD-XXXX-XXXX poids 15` |
| Changer l'origine / destination | `/trajet TWD-XXXX-XXXX Shanghai, China \| Douala, Cameroon` |
| **Faire avancer l'icône** | `/progres TWD-XXXX-XXXX 40` (ou `+10` / `-10`) : 0 = origine, 100 = destination |
| **Changer l'icône** ✈️🚢🚚🚆⚡🚗 | `/transport TWD-XXXX-XXXX air` (air, mer, terre, rail, express, vehicule) |
| Changer le statut | `/statut TWD-XXXX-XXXX transit Dubai` |
| Écrire au client (visible sur le site, email si renseigné) | `/message TWD-XXXX-XXXX Votre colis est à Dubaï.` |
| Position par lieu / coordonnées | `/position TWD-XXXX-XXXX Dubai Hub` · `/position TWD-... 25.2,55.3 Dubai Hub` |
| **Position GPS depuis le téléphone** | `/position TWD-XXXX-XXXX` seul, puis 📎 > Position (ou « Position en direct » : mise à jour auto chaque minute, 12 h max) |
| Nouveau code | `/code TWD-... permanent` (ou `unique`, `temp 24`, `aucun`) |
| Date estimée, infos, historique | `/eta`, `/info`, `/historique`, `/messages` |
| Couper / archiver | `/off` `/on` · `/archiver` `/desarchiver` |
| **Supprimer un ancien code** | `/supprimer TWD-XXXX-XXXX` (confirmation, irréversible : code, historique, positions et messages) |
| **Supprimer tous les anciens codes** | `/nettoyer` (ou `/nettoyer 60`) : liste les codes archivés, coupés (`/off`) ou livrés/annulés depuis plus de N jours (30 par défaut), puis un bouton confirme |
| Demandes de devis du site | `/devis` · `/devis 12 contacte` |
| Vue d'ensemble | `/liste`, `/stats`, `/journal` |

**Comment l'icône avance chez le client.** Elle est posée sur la dernière position enregistrée : `/progres` (déplacement le long de la route origine → destination), `/position` (lieu précis), le GPS du téléphone, ou un statut avec un lieu. Si aucune position n'existe, elle est estimée d'après le pourcentage. Quand le colis est « Delivered », elle est à destination. Les mises à jour arrivent chez le client toutes les 20 s (bouton « Actualiser » pour immédiat).

Conseil : utilisez le code **permanent** (défaut). Un code « usage unique » ne marche qu'une fois : le client ne pourra pas revenir voir ses messages après 30 min.

## Ce que voit le client
Numéro + code (ou lien direct `#/track/TWD-...`) → statut, progression, **messages de l'équipe**, **carte avec le parcours réel** (traits rouges = positions enregistrées, pointillés = reste du trajet), historique. La page se met à jour seule (toutes les 20 s) et signale une mise à jour. La position affichée est toujours présentée comme « partagée par notre équipe » : ce n'est pas un boîtier GPS automatique.

## Sécurité
Secrets uniquement en variables d'environnement · webhook protégé par secret + liste blanche d'ID, conversations privées seulement, limite de débit, anti-doublon · codes hachés (scrypt), affichés une seule fois · cookie d'accès signé HttpOnly · 5 mauvais codes / 15 min / IP · requêtes paramétrées · aucune donnée client (nom, téléphone, email, ID) dans l'API publique · actions du bot inscrites dans `/journal`.

## À faire par vous
- **Emails clients** (optionnel) : compte gratuit Resend + domaine vérifié, puis `RESEND_API_KEY` et `MAIL_FROM`. Sans cela, les emails sont ignorés (statut « skipped » en base) ; le message sur le site fonctionne quand même.
- **Sauvegardes** : activez les sauvegardes/branches de Neon et testez une restauration.
- **Pages légales** (Privacy / Terms / Cookies) : à relire avec un juriste. Rien d'affirmé sans preuve (certifications, bureaux).
- **Nominatim** (géocodage OpenStreetMap, gratuit) : usage léger uniquement ; si le trafic du bot grandit, passez à un service avec clé.

## Tests
`TEST_DATABASE_URL=postgres://... npm test` (après `npm install`) : **vide la base indiquée**, n'utilisez jamais la production.
