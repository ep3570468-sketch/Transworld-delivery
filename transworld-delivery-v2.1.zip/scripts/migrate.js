'use strict';
// Crée / met à jour les tables : DATABASE_URL=... npm run migrate
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
(async () => {
  const url = process.env.DATABASE_URL || process.env.POSTGRES_URL;
  if (!url) { console.error('DATABASE_URL manquant.'); process.exit(1); }
  const pool = new Pool({ connectionString: url });
  try {
    await pool.query(fs.readFileSync(path.join(__dirname, '..', 'sql', 'schema.sql'), 'utf8'));
    const r = await pool.query("SELECT count(*)::int AS n FROM information_schema.tables WHERE table_schema = 'public'");
    console.log('OK : schéma appliqué (' + r.rows[0].n + ' tables).');
  } catch (e) { console.error('Erreur :', e.message); process.exitCode = 1; } finally { await pool.end(); }
})();
