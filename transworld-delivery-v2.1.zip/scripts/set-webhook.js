'use strict';
// Branche le bot sur votre site et installe le menu de commandes :
//   TELEGRAM_TOKEN=... TELEGRAM_SECRET=... SITE_URL=https://www.votre-domaine.com npm run webhook
(async () => {
  const tok = process.env.TELEGRAM_TOKEN, secret = process.env.TELEGRAM_SECRET;
  const site = (process.env.SITE_URL || process.argv[2] || '').replace(/\/+$/, '');
  if (!tok || !secret || !/^https:\/\//.test(site)) { console.error('Il faut TELEGRAM_TOKEN, TELEGRAM_SECRET et SITE_URL (https://...).'); process.exit(1); }
  const api = (m, body) => fetch('https://api.telegram.org/bot' + tok + '/' + m, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) }).then((r) => r.json());
  console.log('setWebhook   :', JSON.stringify(await api('setWebhook', { url: site + '/api/telegram', secret_token: secret, allowed_updates: ['message', 'edited_message', 'callback_query'], drop_pending_updates: true })));
  console.log('setMyCommands:', JSON.stringify(await api('setMyCommands', { commands: [
    { command: 'liste', description: 'Mes colis (boutons)' },
    { command: 'colis', description: "Panneau d'un colis (boutons)" },
    { command: 'nouveau', description: 'Créer un colis + code client' },
    { command: 'progres', description: "Faire avancer l'icône sur la carte" },
    { command: 'statut', description: 'Changer le statut (et le lieu)' },
    { command: 'position', description: 'Mettre à jour la carte (lieu ou GPS)' },
    { command: 'transport', description: "Changer l'icône (avion, bateau, camion…)" },
    { command: 'details', description: 'Ajouter / modifier les informations du colis' },
    { command: 'message', description: 'Envoyer un message au client' },
    { command: 'code', description: "Nouveau code d'accès" },
    { command: 'supprimer', description: 'Supprimer un ancien code de suivi' },
    { command: 'nettoyer', description: 'Supprimer tous les anciens codes' },
    { command: 'devis', description: 'Demandes de devis / contact' },
    { command: 'stats', description: 'Statistiques' },
    { command: 'aide', description: 'Toutes les commandes' },
  ] })));
  const info = await api('getWebhookInfo');
  console.log('getWebhookInfo:', JSON.stringify(info.result || info));
})();
